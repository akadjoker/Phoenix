#pragma once
#include "Config.hpp"
#include <string>
#include <unordered_map>
#include <vector>

class VertexBuffer;
class IndexBuffer;
class VertexArray;
class Mesh;
class MeshBuffer;
class MeshManager;

struct Vertex
{
    float x, y, z;
    float nx, ny, nz;
    float u, v;
};

class MeshBuffer
{
private:
    std::vector<Vertex> vertices;
    std::vector<u32> indices;
    bool m_vdirty;
    bool m_idirty;
    VertexArray *buffer;
    VertexBuffer *vb;
    IndexBuffer *ib;
    u32 m_material{0};
    friend class Mesh;
    friend class MeshManager;

public:
    MeshBuffer();
    ~MeshBuffer();

    void Clear();

    u32 AddVertex(const Vertex &v);
    u32 AddVertex(float x, float y, float z, float u, float v);
    u32 AddVertex(float x, float y, float z, float nx, float ny, float nz, float u, float v);
    u32 AddIndex(u32 index);
    u32 AddFace(u32 i0, u32 i1, u32 i2);

    u32 GetVertexCount() const { return vertices.size(); }
    u32 GetIndexCount() const { return indices.size(); }

    void SetMaterial(u32 material);
    u32 GetMaterial() const { return m_material; }


    void Build();

    void Render();

    void CalculateNormals();
};

class Mesh
{
public:
    Mesh();
    ~Mesh();

    MeshBuffer *AddBuffer(u32 material = 0);
    void Render();
    void CalculateNormals();

private:
    std::vector<MeshBuffer *> buffers;

    friend class MeshBuffer;
    friend class MeshManager;
};

class MeshManager
{
public:
    static MeshManager &Instance();


    Mesh *Get(const std::string &name);
    void Add(const std::string &name, Mesh *mesh);
    bool Exists(const std::string &name) const;

    Mesh *Create(const std::string &name);

    Mesh *CreateCube(const std::string &name,float size = 1.0f);
    Mesh *CreatePlane(const std::string &name,float width = 1.0f, float height = 1.0f, int detailX = 1, int detailY = 1);
    Mesh *CreateSphere(const std::string &name,float radius = 1.0f, int segments = 32, int rings = 16);
    Mesh *CreateCylinder(const std::string &name,float radius = 1.0f, float height = 2.0f, int segments = 32, bool caps = true);
    Mesh *CreateCone(const std::string &name,float radius = 1.0f, float height = 2.0f, int segments = 32);

    void UnloadAll();

private:
    std::unordered_map<std::string, Mesh *> m_meshes;
};