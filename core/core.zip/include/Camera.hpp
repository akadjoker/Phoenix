#pragma once

#include "Transform.hpp"

class Camera
{
protected:
    Transform transform;

    // Parâmetros da projeção
    float fov; // Field of view (graus)
    float aspectRatio;
    float nearPlane;
    float farPlane;

    // Matrizes cached
    Mat4 viewMatrix;
    Mat4 projectionMatrix;
    Mat4 viewProjectionMatrix;
    bool viewDirty;
    bool projectionDirty;

    void UpdateViewMatrix();
    void UpdateProjectionMatrix();

public:
    Camera();
    Camera(float fov, float aspect, float near, float far);
    virtual ~Camera() {}

    // Getters do transform
    Vec3 GetPosition();
    Vec3 GetForward();
    Vec3 GetRight();
    Vec3 GetUp();

    // Setters básicos
    void SetPosition(const Vec3 &position);
    void SetPosition(float x, float y, float z);

    // LookAt
    void LookAt(const Vec3 &target);
    void LookAt(const Vec3 &target, const Vec3 &up);

    // Projeção
    void SetPerspective(float fov, float aspect, float near, float far);
    void SetAspectRatio(float aspect);
    void SetFOV(float fov);

    // Matrizes
    Mat4 GetViewMatrix();
    Mat4 GetProjectionMatrix();
    Mat4 GetViewProjectionMatrix();

    // Acesso ao transform
    Transform &GetTransform();
    const Transform &GetTransform() const;

    // Update (virtual para override)
    virtual void Update(float deltaTime) {}
};

// ==================== Camera FPS ====================
class CameraFPS : public Camera
{
private:
    float pitch;      // Rotação X (olhar cima/baixo)
    float yaw;        // Rotação Y (olhar esquerda/direita)
    float pitchLimit; // Limite para evitar gimbal lock

    float moveSpeed;
    float mouseSensitivity;

public:
    CameraFPS();
    CameraFPS(float fov, float aspect, float near, float far);

    // Controles de movimento (WASD)
    void MoveForward(float distance);
    void MoveBackward(float distance);
    void MoveLeft(float distance);
    void MoveRight(float distance);
    void MoveUp(float distance);
    void MoveDown(float distance);

    // Controles de mouse
    void Rotate(float mouseDeltaX, float mouseDeltaY);
    void SetPitch(float degrees);
    void SetYaw(float degrees);
    float GetPitch() const;
    float GetYaw() const;

    // Configurações
    void SetMoveSpeed(float speed);
    void SetMouseSensitivity(float sensitivity);
    void SetPitchLimit(float limit);

    float GetMoveSpeed() const;
    float GetMouseSensitivity() const;

    // Update automático (chama com input)
    void Update(float deltaTime) override;
};

// ==================== Camera Free (Fly) ====================
class CameraFree : public Camera
{
private:
    Quat rotation;
    float rollAngle;

    float moveSpeed;
    float mouseSensitivity;
    float rollSpeed;

public:
    CameraFree();
    CameraFree(float fov, float aspect, float near, float far);

    // Movimento em 6 direções (sem restrições)
    void MoveForward(float distance);
    void MoveBackward(float distance);
    void MoveLeft(float distance);
    void MoveRight(float distance);
    void MoveUp(float distance);
    void MoveDown(float distance);

    // Rotação livre (pitch, yaw, roll)
    void Rotate(float pitchDelta, float yawDelta);
    void Roll(float degrees);
    void SetRotation(float pitch, float yaw, float roll);

    // Reset orientação
    void ResetOrientation();

    // Configurações
    void SetMoveSpeed(float speed);
    void SetMouseSensitivity(float sensitivity);
    void SetRollSpeed(float speed);

    // Update
    void Update(float deltaTime) override;
};

// ==================== Camera Maya/Orbit ====================
class CameraMaya : public Camera
{
private:
    Vec3 target;     // Ponto de foco
    float distance;  // Distância do target
    float azimuth;   // Ângulo horizontal (graus)
    float elevation; // Ângulo vertical (graus)

    float minDistance;
    float maxDistance;
    float minElevation;
    float maxElevation;

    float orbitSpeed;
    float panSpeed;
    float zoomSpeed;

    void UpdatePosition();

public:
    CameraMaya();
    CameraMaya(float fov, float aspect, float near, float far);

    // Controles Maya-style
    void Orbit(float azimuthDelta, float elevationDelta); // ALT + Left drag
    void Pan(float rightDelta, float upDelta);            // ALT + Middle drag
    void Zoom(float delta);                               // ALT + Right drag / Scroll

    // Setters
    void SetTarget(const Vec3 &target);
    void SetDistance(float distance);
    void SetAzimuth(float degrees);
    void SetElevation(float degrees);

    // Getters
    Vec3 GetTarget() const;
    float GetDistance() const;
    float GetAzimuth() const;
    float GetElevation() const;

    // Limites
    void SetDistanceLimits(float min, float max);
    void SetElevationLimits(float min, float max);

    // Configurações
    void SetOrbitSpeed(float speed);
    void SetPanSpeed(float speed);
    void SetZoomSpeed(float speed);

    // Frame object (ajusta distância para ver objeto inteiro)
    void FrameObject(const Vec3 &center, float radius);

    // Reset para view padrão
    void ResetView();

    // Update
    void Update(float deltaTime) override;
};
