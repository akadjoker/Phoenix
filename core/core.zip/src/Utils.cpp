
#include "pch.h"
#include "Utils.hpp"

#if defined(PLATFORM_DESKTOP) && defined(_WIN32) && (defined(_MSC_VER) || defined(__TINYC__))

    #include "wdirent.h"    // Required for: DIR, opendir(), closedir() [Used in LoadDirectoryFiles()]
#else
    #include <dirent.h>             // Required for: DIR, opendir(), closedir() [Used in LoadDirectoryFiles()]
#endif

#if defined(_WIN32)
    #include <direct.h>             // Required for: _getch(), _chdir()
    #define GETCWD _getcwd          // NOTE: MSDN recommends not to use getcwd(), chdir()
    #define CHDIR _chdir
    #include <io.h>                 // Required for: _access() [Used in FileExists()]
#else
    #include <unistd.h>             // Required for: getch(), chdir() (POSIX), access()
    #define GETCWD getcwd
    #define CHDIR chdir
#endif

#ifdef PLATFORM_WIN

#define CONSOLE_COLOR_RESET ""
#define CONSOLE_COLOR_GREEN ""
#define CONSOLE_COLOR_RED ""
#define CONSOLE_COLOR_PURPLE ""



#else

#define CONSOLE_COLOR_RESET "\033[0m"
#define CONSOLE_COLOR_GREEN "\033[1;32m"
#define CONSOLE_COLOR_RED "\033[1;31m"
#define CONSOLE_COLOR_PURPLE "\033[1;35m"




#endif 

#define MAX_TEXT_BUFFER_LENGTH              512 

static void LogMessage( int level, const char *msg, va_list args )
{
	    time_t rawTime;
		struct tm* timeInfo;
		char timeBuffer[80];



		time(&rawTime);
		timeInfo = localtime(&rawTime);

		strftime(timeBuffer, sizeof(timeBuffer), "[%H:%M:%S]", timeInfo);

        char buffer[1024];
        vsnprintf( buffer, sizeof(buffer), msg, args );

    switch (level)
    {
        case 0:
            SDL_LogInfo(0, "%s%s: %s%s", CONSOLE_COLOR_GREEN,timeBuffer, buffer,CONSOLE_COLOR_RESET);
            break;
        case 1:
            SDL_LogError(0,  "%s%s: %s%s", CONSOLE_COLOR_RED,timeBuffer, buffer,CONSOLE_COLOR_RESET);
            break;
        case 2:
            SDL_LogWarn(0,  "%s%s: %s%s", CONSOLE_COLOR_PURPLE,timeBuffer, buffer,CONSOLE_COLOR_RESET);
            break;
 
    }

}


void LogError( const char *msg, ... )
{
	

	va_list args;
	va_start( args, msg );
	LogMessage( 1, msg, args );
	va_end( args );
}


void LogWarning( const char *msg, ... )
{
	
	va_list args;
	va_start( args, msg );
	LogMessage( 2, msg, args );
	va_end( args );
}


void LogInfo( const char *msg, ... )
{
	va_list args;
	va_start( args, msg );
	LogMessage( 0, msg, args );
	va_end( args );
}

//************************************************************************************************
// Logger Implementation
//************************************************************************************************
 


Logger& Logger::Instance()
{
    static Logger instance;
    return instance;
}
Logger* Logger::InstancePtr()
{
    return  &Instance();
}

Logger::Logger()
{
    LogInfo("[LOGGER] Created");
   
}

Logger::~Logger()
{
    
    LogInfo("[LOGGER] Destroyed");
 
}


void Logger::Error( const char *msg, ... )
{
	va_list args;
	va_start( args, msg );
	LogMessage( 1, msg, args );
	va_end( args );
}


void Logger::Warning( const char *msg, ... )
{
  
	va_list args;
	va_start( args, msg );
	LogMessage( 2, msg, args );
	va_end( args );
}


void Logger::Info( const char *msg, ... )
{
   va_list args;
	va_start( args, msg );
	LogMessage( 0, msg, args );
	va_end( args );
}




// std::string LoadFileSDL(const char* path) 
// {
//     SDL_RWops* rw = SDL_RWFromFile(path, "rb");
//     if (!rw) {
//         SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Shader file open failed: %s (%s)", path, SDL_GetError());
//         return {};
//     }
//     Sint64 size = SDL_RWsize(rw);
//     if (size <= 0) { SDL_RWclose(rw); return {}; }

//     std::string data;
//     data.resize(static_cast<size_t>(size));
//     size_t total = 0;
//     while (total < (size_t)size) {
//         Sint64 readNow = SDL_RWread(rw, &data[total], 1, (size_t)(size - total));
//         if (readNow <= 0) break;
//         total += (size_t)readNow;
//     }
//     SDL_RWclose(rw);

//     if (total != (size_t)size) {
//         SDL_LogWarn(SDL_LOG_CATEGORY_APPLICATION, "Short read for file: %s", path);
//         data.resize(total);
//     }
//     return data;
// }
 
 