
#include <SDL2/SDL.h>

#include <time.h>
#include <sys/stat.h> 
#include <climits>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>


#include <new>
#include <utility>
#include <typeinfo>



#include <algorithm>
#include <map>
#include <unordered_map>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>











