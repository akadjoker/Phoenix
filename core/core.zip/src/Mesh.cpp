#include "pch.h"
#include "Vertex.hpp"
#include "Driver.hpp"
#include "Mesh.hpp"
#include "glad/glad.h"

MeshBuffer::MeshBuffer()
{
    buffer = new VertexArray();
    vb = nullptr;
    ib = nullptr;

    m_vdirty = true;
    m_idirty = true;
}

MeshBuffer::~MeshBuffer()
{
    delete buffer;
}

void MeshBuffer::Clear()
{
    vertices.clear();
    indices.clear();
    m_vdirty = true;
    m_idirty = true;
}

u32 MeshBuffer::AddVertex(const Vertex &v)
{
    vertices.push_back(v);
    m_vdirty = true;
    return vertices.size() - 1;
}

u32 MeshBuffer::AddVertex(float x, float y, float z, float u, float v)
{
    m_vdirty = true;
    return AddVertex({x, y, z, 0, 0, 0, u, v});
}

u32 MeshBuffer::AddVertex(float x, float y, float z, float nx, float ny, float nz, float u, float v)
{
    m_vdirty = true;
    return AddVertex({x, y, z, nx, ny, nz, u, v});
}

u32 MeshBuffer::AddIndex(u32 index)
{
    m_idirty = true;
    indices.push_back(index);
    return indices.size() - 1;
}

u32 MeshBuffer::AddFace(u32 i0, u32 i1, u32 i2)
{
    m_idirty = true;
    indices.push_back(i0);
    indices.push_back(i1);
    indices.push_back(i2);
    return indices.size() - 3;
}

void MeshBuffer::Build()
{

    if (!vb)
    {
        vb = buffer->AddVertexBuffer(sizeof(Vertex), vertices.size(), false);

        auto *decl = buffer->GetVertexDeclaration();
 
        decl->AddElement(0,0, VET_FLOAT3, VES_POSITION);
        decl->AddElement(0,3 * sizeof(float), VET_FLOAT3, VES_NORMAL);
        decl->AddElement(0,6 * sizeof(float), VET_FLOAT2, VES_TEXCOORD,0);

    }

    if (!ib)
    {
        ib = buffer->CreateIndexBuffer(indices.size(), false,false);
    }

    
    if (m_vdirty)
    {
        vb->SetData(vertices.data());
    }

    if (m_idirty)
    {
        ib->SetData(indices.data());
    }
   
    buffer->Build();
    
    m_idirty = false;
    m_vdirty = false;
}

void MeshBuffer::Render()
{
    if (m_idirty || m_vdirty)
    {
        Build();
    }
    buffer->Render(PrimitiveType::PT_TRIANGLES, indices.size()  );
}

void MeshBuffer::CalculateNormals()
{
    for (auto &v : vertices)
    {
        v.nx = v.ny = v.nz = 0.0f;
    }

    for (size_t i = 0; i < indices.size(); i += 3)
    {
        u32 i0 = indices[i];
        u32 i1 = indices[i + 1];
        u32 i2 = indices[i + 2];

        Vertex &v0 = vertices[i0];
        Vertex &v1 = vertices[i1];
        Vertex &v2 = vertices[i2];

        float e1x = v1.x - v0.x;
        float e1y = v1.y - v0.y;
        float e1z = v1.z - v0.z;

        float e2x = v2.x - v0.x;
        float e2y = v2.y - v0.y;
        float e2z = v2.z - v0.z;

        float nx = e1y * e2z - e1z * e2y;
        float ny = e1z * e2x - e1x * e2z;
        float nz = e1x * e2y - e1y * e2x;

        v0.nx += nx;
        v0.ny += ny;
        v0.nz += nz;
        v1.nx += nx;
        v1.ny += ny;
        v1.nz += nz;
        v2.nx += nx;
        v2.ny += ny;
        v2.nz += nz;
    }

    for (auto &v : vertices)
    {
        float len = std::sqrt(v.nx * v.nx + v.ny * v.ny + v.nz * v.nz);
        if (len > 0.0f)
        {
            v.nx /= len;
            v.ny /= len;
            v.nz /= len;
        }
    }
}

MeshBuffer *Mesh::AddBuffer(u32 material)
{
    MeshBuffer *buffer = new MeshBuffer();
    buffer->m_material = material;
    buffers.push_back(buffer);
    return buffer;
}

void Mesh::Render()
{
    for (MeshBuffer *buffer : buffers)
    {
        buffer->Render();
    }
}

void Mesh::CalculateNormals()
{
    for (MeshBuffer *buffer : buffers)
    {
        buffer->CalculateNormals();
    }
}

Mesh::Mesh()
{
}

Mesh::~Mesh()
{
    for (MeshBuffer *buffer : buffers)
    {
        delete buffer;
    }
    buffers.clear();
}

MeshManager &MeshManager::Instance()
{
    static MeshManager instance;
    return instance;
}

Mesh *MeshManager::Get(const std::string &name)
{
    auto it = m_meshes.find(name);
    return (it != m_meshes.end()) ? it->second : nullptr;
}

void MeshManager::Add(const std::string &name, Mesh *mesh)
{
    auto it = m_meshes.find(name);
    if (it != m_meshes.end())
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return;
    }
    m_meshes[name] = mesh;
}

bool MeshManager::Exists(const std::string &name) const
{
    return m_meshes.find(name) != m_meshes.end();
}

Mesh *MeshManager::Create(const std::string &name)
{
    auto it = m_meshes.find(name);
    if (it != m_meshes.end())
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return it->second;
    }
    Mesh *mesh = new Mesh();
    m_meshes[name] = mesh;
    return mesh;
}

Mesh *MeshManager::CreateCube(const std::string &name, float size)
{
    if (Exists(name))
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return Get(name);
    }
    Mesh *mesh = Create(name);
    MeshBuffer *buffer = mesh->AddBuffer(0);

         float h = size * 0.5f;
    
    // Frente (Z+) - olhando para +Z
    u32 v3 = buffer->AddVertex(-h, -h,  h,  0, 0, 1,  0, 0);
    u32 v2 = buffer->AddVertex( h, -h,  h,  0, 0, 1,  1, 0);
    u32 v1 = buffer->AddVertex( h,  h,  h,  0, 0, 1,  1, 1);
    u32 v0 = buffer->AddVertex(-h,  h,  h,  0, 0, 1,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
    // Trás (Z-) - olhando para -Z
    v3 = buffer->AddVertex( h, -h, -h,  0, 0, -1,  0, 0);
    v2 = buffer->AddVertex(-h, -h, -h,  0, 0, -1,  1, 0);
    v1 = buffer->AddVertex(-h,  h, -h,  0, 0, -1,  1, 1);
    v0 = buffer->AddVertex( h,  h, -h,  0, 0, -1,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
    // Direita (X+)
    v3 = buffer->AddVertex( h, -h,  h,  1, 0, 0,  0, 0);
    v2 = buffer->AddVertex( h, -h, -h,  1, 0, 0,  1, 0);
    v1 = buffer->AddVertex( h,  h, -h,  1, 0, 0,  1, 1);
    v0 = buffer->AddVertex( h,  h,  h,  1, 0, 0,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
    // Esquerda (X-)
    v3 = buffer->AddVertex(-h, -h, -h, -1, 0, 0,  0, 0);
    v2 = buffer->AddVertex(-h, -h,  h, -1, 0, 0,  1, 0);
    v1 = buffer->AddVertex(-h,  h,  h, -1, 0, 0,  1, 1);
    v0 = buffer->AddVertex(-h,  h, -h, -1, 0, 0,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
    // Cima (Y+)
    v3 = buffer->AddVertex(-h,  h,  h,  0, 1, 0,  0, 0);
    v2 = buffer->AddVertex( h,  h,  h,  0, 1, 0,  1, 0);
    v1 = buffer->AddVertex( h,  h, -h,  0, 1, 0,  1, 1);
    v0 = buffer->AddVertex(-h,  h, -h,  0, 1, 0,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
    // Baixo (Y-)
    v3 = buffer->AddVertex(-h, -h, -h,  0, -1, 0,  0, 0);
    v2 = buffer->AddVertex( h, -h, -h,  0, -1, 0,  1, 0);
    v1 = buffer->AddVertex( h, -h,  h,  0, -1, 0,  1, 1);
    v0 = buffer->AddVertex(-h, -h,  h,  0, -1, 0,  0, 1);
    buffer->AddFace(v0, v2, v1);
    buffer->AddFace(v0, v3, v2);
    
 

    buffer->CalculateNormals();
    buffer->Build();

    return mesh;
}

Mesh *MeshManager::CreatePlane(const std::string &name, float width, float height, int detailX, int detailY)
{
    if (Exists(name))
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return Get(name);
    }
    Mesh *mesh = Create(name);
    MeshBuffer *buffer = mesh->AddBuffer(0);

    float hw = width * 0.5f;
    float hh = height * 0.5f;

    // Gera vértices
    for (int y = 0; y <= detailY; y++)
    {
        for (int x = 0; x <= detailX; x++)
        {
            float u = (float)x / detailX;
            float v = (float)y / detailY;

            float px = -hw + u * width;
            float py = 0.0f;
            float pz = -hh + v * height;

            buffer->AddVertex(px, py, pz, 0.0f, 1.0f, 0.0f, u, v);
        }
    }

    // Gera índices
    for (int y = 0; y < detailY; y++)
    {
        for (int x = 0; x < detailX; x++)
        {
            u32 i0 = y * (detailX + 1) + x;
            u32 i1 = i0 + 1;
            u32 i2 = (y + 1) * (detailX + 1) + x;
            u32 i3 = i2 + 1;

            buffer->AddFace(i0, i2, i1);
            buffer->AddFace(i1, i2, i3);
        }
    }

        buffer->CalculateNormals();
    buffer->Build();

    return mesh;
}

Mesh *MeshManager::CreateSphere(const std::string &name, float radius, int segments, int rings)
{
    if (Exists(name))
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return Get(name);
    }
    Mesh *mesh = Create(name);
    MeshBuffer *buffer = mesh->AddBuffer(0);

    const float PI = 3.14159265359f;

    // Gera vértices
    for (int ring = 0; ring <= rings; ring++)
    {
        float theta = ring * PI / rings;
        float sinTheta = std::sin(theta);
        float cosTheta = std::cos(theta);

        for (int seg = 0; seg <= segments; seg++)
        {
            float phi = seg * 2.0f * PI / segments;
            float sinPhi = std::sin(phi);
            float cosPhi = std::cos(phi);

            float x = radius * sinTheta * cosPhi;
            float y = radius * cosTheta;
            float z = radius * sinTheta * sinPhi;

            // Normal é a posição normalizada
            float nx = sinTheta * cosPhi;
            float ny = cosTheta;
            float nz = sinTheta * sinPhi;

            float u = (float)seg / segments;
            float v = (float)ring / rings;

            buffer->AddVertex(x, y, z, nx, ny, nz, u, v);
        }
    }

    // Gera índices
    for (int ring = 0; ring < rings; ring++)
    {
        for (int seg = 0; seg < segments; seg++)
        {
            u32 i0 = ring * (segments + 1) + seg;
            u32 i1 = i0 + 1;
            u32 i2 = (ring + 1) * (segments + 1) + seg;
            u32 i3 = i2 + 1;

            buffer->AddFace(i0, i2, i1);
            buffer->AddFace(i1, i2, i3);
        }
    }

        buffer->CalculateNormals();
    buffer->Build();

    return mesh;
}

Mesh *MeshManager::CreateCylinder(const std::string &name, float radius, float height, int segments, bool caps)
{
    if (Exists(name))
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return Get(name);
    }
    Mesh *mesh = Create(name);
    MeshBuffer *buffer = mesh->AddBuffer(0);

    const float PI = 3.14159265359f;
    float halfHeight = height * 0.5f;

    // Corpo do cilindro
    for (int i = 0; i <= segments; i++)
    {
        float angle = (float)i * 2.0f * PI / segments;
        float x = radius * std::cos(angle);
        float z = radius * std::sin(angle);
        float u = (float)i / segments;

        // Normal lateral
        float nx = std::cos(angle);
        float nz = std::sin(angle);

        // Vértice inferior
        buffer->AddVertex(x, -halfHeight, z, nx, 0, nz, u, 0);
        // Vértice superior
        buffer->AddVertex(x, halfHeight, z, nx, 0, nz, u, 1);
    }

    // Índices do corpo
    for (int i = 0; i < segments; i++)
    {
        u32 i0 = i * 2;
        u32 i1 = i0 + 1;
        u32 i2 = (i + 1) * 2;
        u32 i3 = i2 + 1;

        buffer->AddFace(i0, i2, i1);
        buffer->AddFace(i1, i2, i3);
    }

    if (caps)
    {
        u32 baseStart = buffer->vertices.size();

        // Tampa inferior (centro)
        buffer->AddVertex(0, -halfHeight, 0, 0, -1, 0, 0.5f, 0.5f);

        for (int i = 0; i <= segments; i++)
        {
            float angle = (float)i * 2.0f * PI / segments;
            float x = radius * std::cos(angle);
            float z = radius * std::sin(angle);
            float u = 0.5f + 0.5f * std::cos(angle);
            float v = 0.5f + 0.5f * std::sin(angle);

            buffer->AddVertex(x, -halfHeight, z, 0, -1, 0, u, v);
        }

        // Índices tampa inferior
        for (int i = 0; i < segments; i++)
        {
            buffer->AddFace(baseStart, baseStart + i + 2, baseStart + i + 1);
        }

        // Tampa superior (centro)
        u32 topStart = buffer->vertices.size();
        buffer->AddVertex(0, halfHeight, 0, 0, 1, 0, 0.5f, 0.5f);

        for (int i = 0; i <= segments; i++)
        {
            float angle = (float)i * 2.0f * PI / segments;
            float x = radius * std::cos(angle);
            float z = radius * std::sin(angle);
            float u = 0.5f + 0.5f * std::cos(angle);
            float v = 0.5f + 0.5f * std::sin(angle);

            buffer->AddVertex(x, halfHeight, z, 0, 1, 0, u, v);
        }

        // Índices tampa superior
        for (int i = 0; i < segments; i++)
        {
            buffer->AddFace(topStart, topStart + i + 1, topStart + i + 2);
        }
    }

        buffer->CalculateNormals();
    buffer->Build();
    return mesh;
}

Mesh *MeshManager::CreateCone(const std::string &name, float radius, float height, int segments)
{
    if (Exists(name))
    {
        LogWarning("[MeshManager] Mesh already exists: %s", name.c_str());
        return Get(name);
    }
    Mesh *mesh = Create(name);
    MeshBuffer *buffer = mesh->AddBuffer(0);

    const float PI = 3.14159265359f;
    float halfHeight = height * 0.5f;

    // Vértice do topo
    u32 topVertex = buffer->AddVertex(0, halfHeight, 0, 0, 1, 0, 0.5f, 1.0f);

    // Vértices da base
    for (int i = 0; i <= segments; i++)
    {
        float angle = (float)i * 2.0f * PI / segments;
        float x = radius * std::cos(angle);
        float z = radius * std::sin(angle);

        // Calcula normal da lateral (aproximada)
        float slant = std::sqrt(radius * radius + height * height);
        float nx = (x / radius) * (height / slant);
        float ny = radius / slant;
        float nz = (z / radius) * (height / slant);

        buffer->AddVertex(x, -halfHeight, z, nx, ny, nz, (float)i / segments, 0);
    }

    // Faces laterais
    for (int i = 0; i < segments; i++)
    {
        buffer->AddFace(topVertex, i + 1, i + 2);
    }

    // Tampa da base (centro)
    u32 baseCenter = buffer->AddVertex(0, -halfHeight, 0, 0, -1, 0, 0.5f, 0.5f);

    for (int i = 0; i <= segments; i++)
    {
        float angle = (float)i * 2.0f * PI / segments;
        float x = radius * std::cos(angle);
        float z = radius * std::sin(angle);
        float u = 0.5f + 0.5f * std::cos(angle);
        float v = 0.5f + 0.5f * std::sin(angle);

        buffer->AddVertex(x, -halfHeight, z, 0, -1, 0, u, v);
    }

    // Índices da base
    u32 baseStart = baseCenter + 1;
    for (int i = 0; i < segments; i++)
    {
        buffer->AddFace(baseCenter, baseStart + i + 1, baseStart + i);
    }

        buffer->CalculateNormals();
    buffer->Build();

    return mesh;
}

 
void MeshManager::UnloadAll()
{
    if (m_meshes.empty())
        return;
    for (auto it = m_meshes.begin(); it != m_meshes.end(); it++)
    {
        delete it->second;
    }
    m_meshes.clear();
    LogInfo("[MeshManager] Unloaded all meshes");
}
 