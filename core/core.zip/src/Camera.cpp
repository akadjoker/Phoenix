#include "pch.h"
#include "Camera.hpp"

Camera::Camera()
    : Fov(45.0f), AspectRatio(16.0f / 9.0f), NearPlane(0.1f), FarPlane(100.0f), ViewDirty(true), ProjectionDirty(true) {}

Camera::Camera(float fov, float aspect, float near, float far)
    : Fov(fov), AspectRatio(aspect), NearPlane(near), FarPlane(far), ViewDirty(true), ProjectionDirty(true) {}

void Camera::UpdateViewMatrix()
{
    if (!viewDirty)
        return;
    viewMatrix = transform.GetWorldMatrix().Inverse();
    viewDirty = false;
}

void Camera::UpdateProjectionMatrix()
{
    if (!projectionDirty)
        return;
    projectionMatrix = Mat4::PerspectiveDeg(fov, aspectRatio, nearPlane, farPlane);
    projectionDirty = false;
}

Vec3 Camera::GetPosition()  
{
    return transform.GetLocalPosition();
}

Vec3 Camera::GetForward() 
{
    return transform.GetRotation() * Vec3(0, 0, -1);
}

Vec3 Camera::GetRight() 
{
    return transform.GetRotation() * Vec3(1, 0, 0);
}

Vec3 Camera::GetUp() 
{
    return transform.GetRotation() * Vec3(0, 1, 0);
}

void Camera::SetPosition(const Vec3 &position)
{
    transform.SetLocalPosition(position);
    viewDirty = true;
}

void Camera::SetPosition(float x, float y, float z)
{
    SetPosition(Vec3(x, y, z));
}

void Camera::LookAt(const Vec3 &target)
{
    LookAt(target, Vec3(0, 1, 0));
}

void Camera::LookAt(const Vec3 &target, const Vec3 &up)
{
    transform.LookAt(target, up);
    viewDirty = true;
}

void Camera::SetPerspective(float fovDeg, float aspect, float near, float far)
{
    this->fov = fovDeg;
    this->aspectRatio = aspect;
    this->nearPlane = near;
    this->farPlane = far;
    projectionDirty = true;
}

void Camera::SetAspectRatio(float aspect)
{
    this->aspectRatio = aspect;
    projectionDirty = true;
}

void Camera::SetFOV(float fovDeg)
{
    this->fov = fovDeg;
    projectionDirty = true;
}

Mat4 Camera::GetViewMatrix()
{
    UpdateViewMatrix();
    return viewMatrix;
}

Mat4 Camera::GetProjectionMatrix()
{
    UpdateProjectionMatrix();
    return projectionMatrix;
}

Mat4 Camera::GetViewProjectionMatrix()
{
    return GetProjectionMatrix() * GetViewMatrix();
}

Transform &Camera::GetTransform()
{
    return transform;
}

const Transform &Camera::GetTransform() const
{
    return transform;
}

// ==================== Camera FPS ====================

CameraFPS::CameraFPS()
    : Camera(), Pitch(0.0f), Yaw(0.0f), PitchLimit(89.0f), MoveSpeed(5.0f), MouseSensitivity(0.1f) {}

CameraFPS::CameraFPS(float fov, float aspect, float near, float far)
    : Camera(fov, aspect, near, far), Pitch(0.0f), Yaw(0.0f), PitchLimit(89.0f), MoveSpeed(5.0f), MouseSensitivity(0.1f) {}

void CameraFPS::MoveForward(float distance)
{
    Vec3 forward = GetForward();
    forward.y = 0; // Manter no plano horizontal
    forward = forward.Normalized();
    transform.SetLocalPosition(transform.GetLocalPosition() + forward * distance);
    viewDirty = true;
}

void CameraFPS::MoveBackward(float distance)
{
    MoveForward(-distance);
}

void CameraFPS::MoveLeft(float distance)
{
    MoveRight(-distance);
}

void CameraFPS::MoveRight(float distance)
{
    Vec3 right = GetRight();
    right.y = 0; // Manter no plano horizontal
    right = right.Normalized();
    transform.SetLocalPosition(transform.GetLocalPosition() + right * distance);
    viewDirty = true;
}

void CameraFPS::MoveUp(float distance)
{
    transform.SetLocalPosition(transform.GetLocalPosition() + Vec3(0, distance, 0));
    viewDirty = true;
}

void CameraFPS::MoveDown(float distance)
{
    MoveUp(-distance);
}

void CameraFPS::Rotate(float mouseDeltaX, float mouseDeltaY)
{
    yaw += mouseDeltaX * mouseSensitivity;
    pitch -= mouseDeltaY * mouseSensitivity;

    // Limitar pitch para evitar gimbal lock
    if (pitch > pitchLimit)
        pitch = pitchLimit;
    if (pitch < -pitchLimit)
        pitch = -pitchLimit;

    // Normalizar yaw
    while (yaw > 360.0f)
        yaw -= 360.0f;
    while (yaw < 0.0f)
        yaw += 360.0f;

    // Atualizar rotação do transform
    transform.SetLocalRotation(pitch, yaw, 0);
    viewDirty = true;
}

void CameraFPS::SetPitch(float degrees)
{
    pitch = degrees;
    if (pitch > pitchLimit)
        pitch = pitchLimit;
    if (pitch < -pitchLimit)
        pitch = -pitchLimit;
    transform.SetLocalRotation(pitch, yaw, 0);
    viewDirty = true;
}

void CameraFPS::SetYaw(float degrees)
{
    yaw = degrees;
    while (yaw > 360.0f)
        yaw -= 360.0f;
    while (yaw < 0.0f)
        yaw += 360.0f;
    transform.SetLocalRotation(pitch, yaw, 0);
    viewDirty = true;
}

float CameraFPS::GetPitch() const
{
    return pitch;
}

float CameraFPS::GetYaw() const
{
    return yaw;
}

void CameraFPS::SetMoveSpeed(float speed)
{
    moveSpeed = speed;
}

void CameraFPS::SetMouseSensitivity(float sensitivity)
{
    mouseSensitivity = sensitivity;
}

void CameraFPS::SetPitchLimit(float limit)
{
    pitchLimit = limit;
}

float CameraFPS::GetMoveSpeed() const
{
    return moveSpeed;
}

float CameraFPS::GetMouseSensitivity() const
{
    return mouseSensitivity;
}

void CameraFPS::Update(float deltaTime)
{
    // Placeholder para input automático se necessário
}

// ==================== Camera Free ====================

CameraFree::CameraFree()
    : Camera(), Rotation(Quat::Identity()), RollAngle(0.0f), MoveSpeed(10.0f), MouseSensitivity(0.15f), RollSpeed(45.0f) {}

CameraFree::CameraFree(float fov, float aspect, float near, float far)
    : Camera(fov, aspect, near, far), Rotation(Quat::Identity()), RollAngle(0.0f), MoveSpeed(10.0f), MouseSensitivity(0.15f), RollSpeed(45.0f) {}

void CameraFree::MoveForward(float distance)
{
    Vec3 forward = GetForward();
    transform.SetLocalPosition(transform.GetLocalPosition() + forward * distance);
    viewDirty = true;
}

void CameraFree::MoveBackward(float distance)
{
    MoveForward(-distance);
}

void CameraFree::MoveLeft(float distance)
{
    MoveRight(-distance);
}

void CameraFree::MoveRight(float distance)
{
    Vec3 right = GetRight();
    transform.SetLocalPosition(transform.GetLocalPosition() + right * distance);
    viewDirty = true;
}

void CameraFree::MoveUp(float distance)
{
    Vec3 up = GetUp();
    transform.SetLocalPosition(transform.GetLocalPosition() + up * distance);
    viewDirty = true;
}

void CameraFree::MoveDown(float distance)
{
    MoveUp(-distance);
}

void CameraFree::Rotate(float pitchDelta, float yawDelta)
{
    // Rotação livre sem restrições
    Quat pitch = Quat::RotationXDeg(pitchDelta * mouseSensitivity);
    Quat yaw = Quat::RotationYDeg(-yawDelta * mouseSensitivity);

    rotation = yaw * rotation * pitch;
    rotation.Normalize();

    transform.SetLocalRotation(rotation);
    viewDirty = true;
}

void CameraFree::Roll(float degrees)
{
    rollAngle += degrees;

    Quat rollQuat = Quat::RotationZDeg(rollAngle);
    rotation = rotation * rollQuat;
    rotation.Normalize();

    transform.SetLocalRotation(rotation);
    viewDirty = true;
}

void CameraFree::SetRotation(float pitch, float yaw, float roll)
{
    rollAngle = roll;
    rotation = Quat::FromEulerAnglesDeg(pitch, yaw, roll);
    transform.SetLocalRotation(rotation);
    viewDirty = true;
}

void CameraFree::ResetOrientation()
{
    rotation = Quat::Identity();
    rollAngle = 0.0f;
    transform.SetLocalRotation(rotation);
    viewDirty = true;
}

void CameraFree::SetMoveSpeed(float speed)
{
    moveSpeed = speed;
}

void CameraFree::SetMouseSensitivity(float sensitivity)
{
    mouseSensitivity = sensitivity;
}

void CameraFree::SetRollSpeed(float speed)
{
    rollSpeed = speed;
}

void CameraFree::Update(float deltaTime)
{
    // Placeholder para input automático se necessário
}

// ==================== Camera Maya ====================

CameraMaya::CameraMaya()
    : Camera(), Target(0, 0, 0), Distance(10.0f), Azimuth(45.0f), Elevation(30.0f), MinDistance(1.0f), MaxDistance(100.0f), MinElevation(-89.0f), MaxElevation(89.0f), OrbitSpeed(0.5f), PanSpeed(0.01f), ZoomSpeed(1.0f)
{
    UpdatePosition();
}

CameraMaya::CameraMaya(float fov, float aspect, float near, float far)
    : Camera(fov, aspect, near, far), Target(0, 0, 0), Distance(10.0f), Azimuth(45.0f), Elevation(30.0f), MinDistance(1.0f), MaxDistance(100.0f), MinElevation(-89.0f), MaxElevation(89.0f), OrbitSpeed(0.5f), PanSpeed(0.01f), ZoomSpeed(1.0f)
{
    UpdatePosition();
}

void CameraMaya::UpdatePosition()
{
    // Converter coordenadas esféricas para cartesianas
    float azimuthRad = ToRadians(azimuth);
    float elevationRad = ToRadians(elevation);

    float x = target.x + distance * std::Cos(elevationRad) * std::Sin(azimuthRad);
    float y = target.y + distance * std::Sin(elevationRad);
    float z = target.z + distance * std::Cos(elevationRad) * std::Cos(azimuthRad);

    transform.SetLocalPosition(x, y, z);
    transform.LookAt(target, Vec3(0, 1, 0));
    viewDirty = true;
}

void CameraMaya::Orbit(float azimuthDelta, float elevationDelta)
{
    azimuth += azimuthDelta * orbitSpeed;
    elevation += elevationDelta * orbitSpeed;

    // Normalizar azimuth
    while (azimuth > 360.0f)
        azimuth -= 360.0f;
    while (azimuth < 0.0f)
        azimuth += 360.0f;

    // Limitar elevation
    if (elevation > maxElevation)
        elevation = maxElevation;
    if (elevation < minElevation)
        elevation = minElevation;

    UpdatePosition();
}

void CameraMaya::Pan(float rightDelta, float upDelta)
{
    Vec3 right = GetRight() * rightDelta * panSpeed * distance;
    Vec3 up = GetUp() * upDelta * panSpeed * distance;

    target = target + right + up;
    UpdatePosition();
}

void CameraMaya::Zoom(float delta)
{
    distance -= delta * zoomSpeed;

    // Limitar distância
    if (distance < minDistance)
        distance = minDistance;
    if (distance > maxDistance)
        distance = maxDistance;

    UpdatePosition();
}

void CameraMaya::SetTarget(const Vec3 &newTarget)
{
    target = newTarget;
    UpdatePosition();
}

void CameraMaya::SetDistance(float dist)
{
    distance = dist;
    if (distance < minDistance)
        distance = minDistance;
    if (distance > maxDistance)
        distance = maxDistance;
    UpdatePosition();
}

void CameraMaya::SetAzimuth(float degrees)
{
    azimuth = degrees;
    while (azimuth > 360.0f)
        azimuth -= 360.0f;
    while (azimuth < 0.0f)
        azimuth += 360.0f;
    UpdatePosition();
}

void CameraMaya::SetElevation(float degrees)
{
    elevation = degrees;
    if (elevation > maxElevation)
        elevation = maxElevation;
    if (elevation < minElevation)
        elevation = minElevation;
    UpdatePosition();
}

Vec3 CameraMaya::GetTarget() const
{
    return target;
}

float CameraMaya::GetDistance() const
{
    return distance;
}

float CameraMaya::GetAzimuth() const
{
    return azimuth;
}

float CameraMaya::GetElevation() const
{
    return elevation;
}

void CameraMaya::SetDistanceLimits(float min, float max)
{
    minDistance = min;
    maxDistance = max;
    if (distance < minDistance)
        distance = minDistance;
    if (distance > maxDistance)
        distance = maxDistance;
    UpdatePosition();
}

void CameraMaya::SetElevationLimits(float min, float max)
{
    minElevation = min;
    maxElevation = max;
    if (elevation < minElevation)
        elevation = minElevation;
    if (elevation > maxElevation)
        elevation = maxElevation;
    UpdatePosition();
}

void CameraMaya::SetOrbitSpeed(float speed)
{
    orbitSpeed = speed;
}

void CameraMaya::SetPanSpeed(float speed)
{
    panSpeed = speed;
}

void CameraMaya::SetZoomSpeed(float speed)
{
    zoomSpeed = speed;
}

void CameraMaya::FrameObject(const Vec3 &center, float radius)
{
    target = center;

    // Calcular distância para ver o objeto inteiro
    float fovRad = ToRadians(fov);
    distance = radius / std::Tan(fovRad * 0.5f) * 1.5f; // 1.5x margin

    if (distance < minDistance)
        distance = minDistance;
    if (distance > maxDistance)
        distance = maxDistance;

    UpdatePosition();
}

void CameraMaya::ResetView()
{
    azimuth = 45.0f;
    elevation = 30.0f;
    distance = 10.0f;
    target = Vec3(0, 0, 0);
    UpdatePosition();
}

void CameraMaya::Update(float deltaTime)
{
}
