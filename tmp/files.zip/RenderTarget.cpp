#include "RenderTarget.hpp"

// ============================================================================
// Construtor / Destrutor
// ============================================================================

RenderTarget::RenderTarget(u32 w, u32 h)
    : fbo(0), width(w), height(h)
{
    glGenFramebuffers(1, &fbo);
}

RenderTarget::~RenderTarget()
{
    for (auto &att : attachments)
    {
        if (att.isTexture && att.texture)
            delete att.texture;
        else if (!att.isTexture && att.renderbuffer != 0)
            glDeleteRenderbuffers(1, &att.renderbuffer);
    }
    
    if (fbo != 0)
        glDeleteFramebuffers(1, &fbo);
}

// ============================================================================
// Adicionar Attachments - Métodos simplificados
// ============================================================================

void RenderTarget::AddColorAttachment(TextureFormat format, const std::string &name, bool useTexture)
{
    AttachmentConfig config;
    config.type = AttachmentType::COLOR;
    config.format = format;
    config.useTexture = useTexture;
    config.name = name;
    AddAttachment(config);
}

void RenderTarget::AddDepthAttachment(TextureFormat format, bool useTexture)
{
    AttachmentConfig config;
    config.type = AttachmentType::DEPTH;
    config.format = format;
    config.useTexture = useTexture;
    config.name = "depth";
    AddAttachment(config);
}

void RenderTarget::AddDepthStencilAttachment(bool useTexture)
{
    AttachmentConfig config;
    config.type = AttachmentType::DEPTH_STENCIL;
    config.format = TextureFormat::DEPTH24_STENCIL8;
    config.useTexture = useTexture;
    config.name = "depth_stencil";
    AddAttachment(config);
}

// ============================================================================
// Adicionar Attachment - Método principal
// ============================================================================

void RenderTarget::AddAttachment(const AttachmentConfig &config)
{
    Attachment att;
    att.type = config.type;
    att.isTexture = config.useTexture;
    att.name = config.name;
    att.texture = nullptr;
    att.renderbuffer = 0;

    if (config.useTexture)
    {
        // Criar textura usando a classe Texture
        att.texture = new Texture();
        att.texture->SetName(config.name);
        att.texture->SetMinFilter(config.minFilter);
        att.texture->SetMagFilter(config.magFilter);
        att.texture->SetWrap(config.wrap);
        
        if (!att.texture->Create(width, height, config.format, nullptr))
        {
            LogError("[RenderTarget] Failed to create texture attachment: %s", config.name.c_str());
            delete att.texture;
            att.texture = nullptr;
            return;
        }
    }
    else
    {
        // Criar renderbuffer
        glGenRenderbuffers(1, &att.renderbuffer);
        glBindRenderbuffer(GL_RENDERBUFFER, att.renderbuffer);
        
        u32 internalFormat = ToGLFormat(config.format);
        glRenderbufferStorage(GL_RENDERBUFFER, internalFormat, width, height);
        glBindRenderbuffer(GL_RENDERBUFFER, 0);
    }

    attachments.push_back(att);
}

// ============================================================================
// Build - Finalizar configuração do framebuffer
// ============================================================================

bool RenderTarget::Build()
{
    if (attachments.empty())
    {
        LogError("[RenderTarget] No attachments to build");
        return false;
    }

    glBindFramebuffer(GL_FRAMEBUFFER, fbo);

    u32 colorIndex = 0;
    colorAttachments.clear();

    for (auto &att : attachments)
    {
        if (att.type == AttachmentType::COLOR)
        {
            u32 attachPoint = GL_COLOR_ATTACHMENT0 + colorIndex;
            
            if (att.isTexture && att.texture)
                glFramebufferTexture2D(GL_FRAMEBUFFER, attachPoint, GL_TEXTURE_2D, 
                                      att.texture->GetHandle(), 0);
            else if (!att.isTexture)
                glFramebufferRenderbuffer(GL_FRAMEBUFFER, attachPoint, 
                                         GL_RENDERBUFFER, att.renderbuffer);
            
            colorAttachments.push_back(attachPoint);
            colorIndex++;
        }
        else if (att.type == AttachmentType::DEPTH)
        {
            if (att.isTexture && att.texture)
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, 
                                      GL_TEXTURE_2D, att.texture->GetHandle(), 0);
            else if (!att.isTexture)
                glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, 
                                         GL_RENDERBUFFER, att.renderbuffer);
        }
        else if (att.type == AttachmentType::DEPTH_STENCIL)
        {
            if (att.isTexture && att.texture)
                glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, 
                                      GL_TEXTURE_2D, att.texture->GetHandle(), 0);
            else if (!att.isTexture)
                glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, 
                                         GL_RENDERBUFFER, att.renderbuffer);
        }
    }

    // Configurar draw buffers
    if (!colorAttachments.empty())
        glDrawBuffers(colorAttachments.size(), colorAttachments.data());
    else
        glDrawBuffer(GL_NONE);

    // Verificar status
    bool complete = IsComplete();
    if (!complete)
        LogError("[RenderTarget] Framebuffer incomplete: %s", GetStatusString());
    else
        LogInfo("[RenderTarget] Created (%ux%u) with %zu attachments", 
                width, height, attachments.size());

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return complete;
}

// ============================================================================
// Binding
// ============================================================================

void RenderTarget::Bind()
{
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(0, 0, width, height);
}

void RenderTarget::Unbind()
{
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void RenderTarget::BindDefault()
{
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// ============================================================================
// Obter Texturas
// ============================================================================

Texture *RenderTarget::GetTexture(const std::string &name) const
{
    for (const auto &att : attachments)
    {
        if (att.name == name && att.isTexture)
            return att.texture;
    }
    return nullptr;
}

Texture *RenderTarget::GetTexture(u32 index) const
{
    u32 colorIndex = 0;
    for (const auto &att : attachments)
    {
        if (att.type == AttachmentType::COLOR)
        {
            if (colorIndex == index && att.isTexture)
                return att.texture;
            colorIndex++;
        }
    }
    return nullptr;
}

Texture *RenderTarget::GetDepthTexture() const
{
    for (const auto &att : attachments)
    {
        if ((att.type == AttachmentType::DEPTH || att.type == AttachmentType::DEPTH_STENCIL) 
            && att.isTexture)
            return att.texture;
    }
    return nullptr;
}

u32 RenderTarget::GetTextureID(u32 index) const
{
    Texture *tex = GetTexture(index);
    return tex ? tex->GetHandle() : 0;
}

// ============================================================================
// Utilitários
// ============================================================================

void RenderTarget::Resize(u32 w, u32 h)
{
    if (w == width && h == height)
        return;

    width = w;
    height = h;

    // Recriar todas as texturas e renderbuffers
    for (auto &att : attachments)
    {
        if (att.isTexture && att.texture)
        {
            TextureFormat format = att.texture->GetFormat();
            FilterMode minFilter = att.texture->GetMinFilter();
            FilterMode magFilter = att.texture->GetMagFilter();
            
            att.texture->Release();
            att.texture->SetMinFilter(minFilter);
            att.texture->SetMagFilter(magFilter);
            att.texture->Create(width, height, format, nullptr);
        }
        else if (!att.isTexture && att.renderbuffer != 0)
        {
            glBindRenderbuffer(GL_RENDERBUFFER, att.renderbuffer);
            // Precisamos saber o formato... vamos guardar na struct
            // Por agora vamos assumir RGBA8 ou DEPTH24
            glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8, width, height);
            glBindRenderbuffer(GL_RENDERBUFFER, 0);
        }
    }

    // Rebuild framebuffer
    Build();
}

void RenderTarget::Clear(u32 mask)
{
    glClear(mask);
}

// ============================================================================
// Verificação
// ============================================================================

bool RenderTarget::IsComplete() const
{
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    u32 status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return status == GL_FRAMEBUFFER_COMPLETE;
}

const char *RenderTarget::GetStatusString() const
{
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    u32 status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    switch (status)
    {
    case GL_FRAMEBUFFER_COMPLETE:
        return "Complete";
    case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
        return "Incomplete attachment";
    case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
        return "Missing attachment";
    case GL_FRAMEBUFFER_UNSUPPORTED:
        return "Unsupported";
    case GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE:
        return "Incomplete multisample";
    default:
        return "Unknown error";
    }
}

// ============================================================================
// Blit Operations
// ============================================================================

void RenderTarget::BlitDepthTo(RenderTarget *target)
{
    if (!target)
        return;

    glBindFramebuffer(GL_READ_FRAMEBUFFER, fbo);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, target->fbo);
    glBlitFramebuffer(0, 0, width, height, 
                     0, 0, target->width, target->height,
                     GL_DEPTH_BUFFER_BIT, GL_NEAREST);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void RenderTarget::BlitColorTo(RenderTarget *target, u32 srcIndex, u32 dstIndex)
{
    if (!target)
        return;

    glBindFramebuffer(GL_READ_FRAMEBUFFER, fbo);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, target->fbo);
    
    glReadBuffer(GL_COLOR_ATTACHMENT0 + srcIndex);
    glDrawBuffer(GL_COLOR_ATTACHMENT0 + dstIndex);
    
    glBlitFramebuffer(0, 0, width, height,
                     0, 0, target->width, target->height,
                     GL_COLOR_BUFFER_BIT, GL_LINEAR);
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

// ============================================================================
// FACTORY - Configurações pré-definidas
// ============================================================================

namespace RenderTargetFactory
{

RenderTarget *CreateGBuffer(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    // Position (RGB32F para precisão)
    rt->AddColorAttachment(TextureFormat::RGB32F, "gPosition");
    
    // Normal (RGB16F suficiente)
    rt->AddColorAttachment(TextureFormat::RGB16F, "gNormal");
    
    // Albedo + Specular (RGBA8)
    rt->AddColorAttachment(TextureFormat::RGBA8, "gAlbedoSpec");
    
    // Depth
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    LogInfo("[Factory] Created GBuffer (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreateShadowMap(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    // Apenas depth texture
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    // Configurar textura para shadow mapping
    Texture *depthTex = rt->GetDepthTexture();
    if (depthTex)
    {
        depthTex->SetMinFilter(FilterMode::LINEAR);
        depthTex->SetMagFilter(FilterMode::LINEAR);
        depthTex->SetWrap(WrapMode::CLAMP_TO_BORDER);
        depthTex->SetBorderColor(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    LogInfo("[Factory] Created ShadowMap (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreateWaterReflection(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    rt->AddColorAttachment(TextureFormat::RGBA8, "reflection");
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    LogInfo("[Factory] Created WaterReflection (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreateWaterRefraction(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    rt->AddColorAttachment(TextureFormat::RGBA8, "refraction");
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    LogInfo("[Factory] Created WaterRefraction (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreateHDR(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    // HDR color buffer
    rt->AddColorAttachment(TextureFormat::RGBA16F, "hdr");
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    LogInfo("[Factory] Created HDR buffer (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreatePostProcess(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    rt->AddColorAttachment(TextureFormat::RGBA8, "color");
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    LogInfo("[Factory] Created PostProcess buffer (%ux%u)", width, height);
    return rt;
}

RenderTarget *CreateSSAO(u32 width, u32 height)
{
    RenderTarget *rt = new RenderTarget(width, height);
    
    // SSAO precisa apenas de um canal (R8 ou R16F)
    rt->AddColorAttachment(TextureFormat::R8, "ssao");
    
    if (!rt->Build())
    {
        delete rt;
        return nullptr;
    }
    
    // Configurar filtro para suavização
    Texture *ssaoTex = rt->GetTexture(0);
    if (ssaoTex)
    {
        ssaoTex->SetMinFilter(FilterMode::LINEAR);
        ssaoTex->SetMagFilter(FilterMode::LINEAR);
    }
    
    LogInfo("[Factory] Created SSAO buffer (%ux%u)", width, height);
    return rt;
}

} // namespace RenderTargetFactory
