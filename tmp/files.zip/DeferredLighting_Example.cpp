// ============================================================================
// EXEMPLO: Deferred Lighting com Transform
// Quake/Doom style - muitas luzes dinâmicas
// ============================================================================

#include "Core.hpp"
#include "DeferredLighting.hpp"
#include "DeferredLighting_Shaders.hpp"

int main()
{
    Device &device = Device::Instance();
    device.Create(1024, 768, "Deferred Lighting", true, 1);
    
    Driver &driver = Driver::Instance();
    TextureManager::Instance().Init();
    
    Texture *texture = TextureManager::Instance().Add("wall.jpg");
    
    Camera camera;
    camera.setPosition(Vec3(0, 5, 15));
    camera.setTarget(Vec3(0, 0, 0));
    camera.setPerspective(60.0f, 1024.0f / 768.0f, 0.1f, 100.0f);
    
    Mesh *cube = MeshManager::Instance().CreateCube("cube");
    Mesh *plane = MeshManager::Instance().CreatePlane("plane", 20, 20, 1, 1);
    
    // ========================================
    // CRIAR DEFERRED LIGHTING
    // ========================================
    
    DeferredLighting *deferred = new DeferredLighting(1024, 768);
    
    // ========================================
    // SHADERS
    // ========================================
    
    Shader *gbufferShader = ShaderManager::Instance().Create("gbuffer",
        deferredGBufferVS, deferredGBufferFS);
    
    Shader *pointLightShader = ShaderManager::Instance().Create("pointLight",
        pointLightVS, pointLightFS);
    
    Shader *spotLightShader = ShaderManager::Instance().Create("spotLight",
        spotLightVS, spotLightFS);
    
    Shader *ambientShader = ShaderManager::Instance().Create("ambient",
        ambientVS, ambientFS);
    
    // ========================================
    // CRIAR LUZES (usando Transform!)
    // ========================================
    
    // Point lights
    PointLight light1;
    light1.SetPosition(Vec3(5, 2, 0));
    light1.color = Vec3(1, 0, 0); // Vermelha
    light1.radius = 10.0f;
    light1.intensity = 1.0f;
    deferred->AddPointLight(light1);
    
    PointLight light2;
    light2.SetPosition(Vec3(-5, 2, 0));
    light2.color = Vec3(0, 1, 0); // Verde
    light2.radius = 10.0f;
    deferred->AddPointLight(light2);
    
    PointLight light3;
    light3.SetPosition(Vec3(0, 2, 5));
    light3.color = Vec3(0, 0, 1); // Azul
    light3.radius = 10.0f;
    deferred->AddPointLight(light3);
    
    // Spot light (lanterna)
    SpotLight flashlight;
    flashlight.color = Vec3(1, 1, 0.8f);
    flashlight.radius = 20.0f;
    flashlight.innerCone = 15.0f;
    flashlight.outerCone = 25.0f;
    flashlight.intensity = 2.0f;
    deferred->AddSpotLight(flashlight);
    
    QuadRenderer quad;
    
    // ========================================
    // MAIN LOOP
    // ========================================
    
    while (device.IsRunning())
    {
        float dt = device.GetFrameTime();
        float time = device.GetTime();
        
        // Input...
        camera.update(dt);
        
        const Mat4 &view = camera.getViewMatrix();
        const Mat4 &proj = camera.getProjectionMatrix();
        const Vec3 &cameraPos = camera.getPosition();
        
        // ========================================
        // ANIMAR LUZES (usando Transform!)
        // ========================================
        
        // Animar point lights em círculo
        auto *pl1 = deferred->GetPointLight(0);
        pl1->SetPosition(Vec3(sin(time) * 8, 2, cos(time) * 8));
        
        auto *pl2 = deferred->GetPointLight(1);
        pl2->SetPosition(Vec3(sin(time + 2) * 8, 2, cos(time + 2) * 8));
        
        auto *pl3 = deferred->GetPointLight(2);
        pl3->SetPosition(Vec3(sin(time + 4) * 8, 2, cos(time + 4) * 8));
        
        // Spotlight segue a câmera (lanterna)
        auto *spotlight = deferred->GetSpotLight(0);
        spotlight->SetPosition(cameraPos);
        spotlight->transform.setRotation(camera.getRotation());
        
        // ========================================
        // PASS 1: GBUFFER
        // ========================================
        
        deferred->BeginGBufferPass();
        
        gbufferShader->Bind();
        gbufferShader->SetUniformMat4("view", view.m);
        gbufferShader->SetUniformMat4("projection", proj.m);
        gbufferShader->SetUniform("texture_diffuse", 0);
        gbufferShader->SetUniform("specular", 0.5f);
        
        texture->Bind(0);
        
        // Render scene
        Mat4 model = Mat4::Scale(Vec3(10, 1, 10));
        gbufferShader->SetUniformMat4("model", model.m);
        plane->Render();
        
        Vec3 cubePositions[] = {
            Vec3(0, 1, 0), Vec3(3, 1, 3), Vec3(-3, 1, 3),
            Vec3(3, 1, -3), Vec3(-3, 1, -3)
        };
        
        for (int i = 0; i < 5; i++)
        {
            model = Mat4::Translation(cubePositions[i]);
            gbufferShader->SetUniformMat4("model", model.m);
            cube->Render();
        }
        
        deferred->EndGBufferPass();
        
        // ========================================
        // PASS 2: LIGHTING
        // ========================================
        
        deferred->BeginLightingPass();
        
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE); // Additive blending
        
        deferred->BindGBufferTextures(0);
        
        // 2.1 - Ambient
        ambientShader->Bind();
        ambientShader->SetUniform("gAlbedoSpec", 2);
        ambientShader->SetUniform("ambientColor", 0.1f, 0.1f, 0.15f);
        ambientShader->SetUniform("ambientStrength", 1.0f);
        quad.render();
        
        // 2.2 - Point Lights (render light volumes!)
        pointLightShader->Bind();
        pointLightShader->SetUniform("gPosition", 0);
        pointLightShader->SetUniform("gNormal", 1);
        pointLightShader->SetUniform("gAlbedoSpec", 2);
        pointLightShader->SetUniformMat4("view", view.m);
        pointLightShader->SetUniformMat4("projection", proj.m);
        pointLightShader->SetUniform("viewPos", cameraPos.x, cameraPos.y, cameraPos.z);
        pointLightShader->SetUniform("screenSize", 1024.0f, 768.0f);
        
        glEnable(GL_CULL_FACE);
        glCullFace(GL_FRONT); // Render interior da esfera
        
        for (const auto &light : deferred->GetPointLights())
        {
            Vec3 pos = light.GetPosition();
            
            // Scale esfera pelo radius
            Mat4 lightModel = Mat4::Translation(pos) * Mat4::Scale(Vec3(light.radius));
            
            pointLightShader->SetUniformMat4("model", lightModel.m);
            pointLightShader->SetUniform("lightPos", pos.x, pos.y, pos.z);
            pointLightShader->SetUniform("lightColor", light.color.x, light.color.y, light.color.z);
            pointLightShader->SetUniform("lightRadius", light.radius);
            pointLightShader->SetUniform("lightIntensity", light.intensity);
            
            deferred->GetSphereMesh()->Render();
        }
        
        // 2.3 - Spot Lights
        spotLightShader->Bind();
        spotLightShader->SetUniform("gPosition", 0);
        spotLightShader->SetUniform("gNormal", 1);
        spotLightShader->SetUniform("gAlbedoSpec", 2);
        spotLightShader->SetUniformMat4("view", view.m);
        spotLightShader->SetUniformMat4("projection", proj.m);
        spotLightShader->SetUniform("viewPos", cameraPos.x, cameraPos.y, cameraPos.z);
        spotLightShader->SetUniform("screenSize", 1024.0f, 768.0f);
        
        for (const auto &light : deferred->GetSpotLights())
        {
            Vec3 pos = light.GetPosition();
            Vec3 dir = light.GetDirection();
            
            // Matriz do cone (usa Transform!)
            Mat4 lightModel = light.transform.getWorldMatrix();
            lightModel = lightModel * Mat4::Scale(Vec3(light.radius));
            
            float innerCos = cos(ToRadians(light.innerCone));
            float outerCos = cos(ToRadians(light.outerCone));
            
            spotLightShader->SetUniformMat4("model", lightModel.m);
            spotLightShader->SetUniform("lightPos", pos.x, pos.y, pos.z);
            spotLightShader->SetUniform("lightDir", dir.x, dir.y, dir.z);
            spotLightShader->SetUniform("lightColor", light.color.x, light.color.y, light.color.z);
            spotLightShader->SetUniform("lightRadius", light.radius);
            spotLightShader->SetUniform("lightIntensity", light.intensity);
            spotLightShader->SetUniform("innerCone", innerCos);
            spotLightShader->SetUniform("outerCone", outerCos);
            
            deferred->GetConeMesh()->Render();
        }
        
        glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);
        
        deferred->EndLightingPass();
        
        // ========================================
        // PASS 3: FINAL (copiar para ecrã)
        // ========================================
        
        RenderTarget::BindDefault();
        driver.Clear(CLEAR_COLOR | CLEAR_DEPTH);
        
        // Simplesmente mostrar o lighting buffer
        // (ou adicionar post-processing aqui)
        
        device.Flip();
    }
    
    delete deferred;
    
    MeshManager::Instance().UnloadAll();
    ShaderManager::Instance().UnloadAll();
    TextureManager::Instance().UnloadAll();
    device.Close();
    
    return 0;
}
