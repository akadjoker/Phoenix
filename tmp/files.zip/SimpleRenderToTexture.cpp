// ============================================================================
// EXEMPLO SIMPLES: Render to Texture
// ============================================================================

#include "RenderTarget.hpp"

void SimpleRenderToTexture()
{
    // 1. CRIAR RENDER TARGET (512x512)
    RenderTarget *rt = new RenderTarget(512, 512);
    rt->AddColorAttachment(TextureFormat::RGBA8, "color");
    rt->AddDepthAttachment(TextureFormat::DEPTH24);
    rt->Build();

    // 2. RENDER PARA A TEXTURA
    rt->Bind();
    rt->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Render o que quiseres aqui
    shader->Bind();
    cube->Render();
    
    rt->Unbind();

    // 3. USAR A TEXTURA NO ECRÃ
    RenderTarget::BindDefault();
    
    textureShader->Bind();
    rt->GetTexture("color")->Bind(0);  // Bind a textura gerada
    textureShader->SetUniform("tex", 0);
    
    quad->Render();  // Desenhar fullscreen quad com a textura

    // 4. CLEANUP
    delete rt;
}

// ============================================================================
// EXEMPLO: Mirror/Rear View Mirror
// ============================================================================

void RearViewMirror()
{
    // Criar textura 256x256 para o espelho retrovisor
    RenderTarget *mirror = new RenderTarget(256, 256);
    mirror->AddColorAttachment(TextureFormat::RGBA8, "mirror");
    mirror->AddDepthAttachment(TextureFormat::DEPTH24);
    mirror->Build();

    // Loop principal
    while (running)
    {
        // PASSO 1: Render vista de trás para a textura
        mirror->Bind();
        mirror->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        Camera backCamera;
        backCamera.SetPosition(carPosition - carForward * 5.0f);  // 5m atrás
        backCamera.LookAt(carPosition);
        
        shader->Bind();
        shader->SetUniformMat4("view", backCamera.GetViewMatrix());
        shader->SetUniformMat4("projection", backCamera.GetProjectionMatrix());
        
        RenderScene();  // Render a cena da vista de trás
        
        mirror->Unbind();

        // PASSO 2: Render cena normal
        RenderTarget::BindDefault();
        driver.Clear(CLEAR_COLOR | CLEAR_DEPTH);
        
        shader->Bind();
        shader->SetUniformMat4("view", mainCamera.GetViewMatrix());
        shader->SetUniformMat4("projection", mainCamera.GetProjectionMatrix());
        
        RenderScene();  // Render cena normal
        
        // PASSO 3: Desenhar espelho retrovisor como UI
        // (pequeno quad no canto superior com a textura do mirror)
        uiShader->Bind();
        mirror->GetTexture("mirror")->Bind(0);
        uiShader->SetUniform("mirrorTexture", 0);
        
        // Desenhar quad no canto superior direito
        DrawMirrorQuad(screenWidth - 256, 0, 256, 256);
    }

    delete mirror;
}

// ============================================================================
// EXEMPLO: Screenshot/Thumbnail
// ============================================================================

void TakeScreenshot()
{
    // Render em resolução menor para thumbnail
    RenderTarget *thumbnail = new RenderTarget(256, 256);
    thumbnail->AddColorAttachment(TextureFormat::RGBA8, "screenshot");
    thumbnail->Build();

    // Render
    thumbnail->Bind();
    thumbnail->Clear(GL_COLOR_BUFFER_BIT);
    
    shader->Bind();
    RenderScene();
    
    thumbnail->Unbind();

    // Ler pixels
    thumbnail->Bind();
    unsigned char *pixels = new unsigned char[256 * 256 * 4];
    glReadPixels(0, 0, 256, 256, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
    thumbnail->Unbind();

    // Guardar ficheiro (usando stb_image_write ou similar)
    stbi_write_png("screenshot.png", 256, 256, 4, pixels, 256 * 4);
    
    delete[] pixels;
    delete thumbnail;
}

// ============================================================================
// EXEMPLO: Picture in Picture
// ============================================================================

void PictureInPicture()
{
    // Criar textura para a segunda câmera
    RenderTarget *pip = new RenderTarget(320, 240);
    pip->AddColorAttachment(TextureFormat::RGBA8, "pip");
    pip->AddDepthAttachment(TextureFormat::DEPTH24);
    pip->Build();

    Camera mainCam, secondCam;

    while (running)
    {
        // Render segunda câmera para textura
        pip->Bind();
        pip->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        shader->Bind();
        shader->SetUniformMat4("view", secondCam.GetViewMatrix());
        shader->SetUniformMat4("projection", secondCam.GetProjectionMatrix());
        RenderScene();
        
        pip->Unbind();

        // Render câmera principal
        RenderTarget::BindDefault();
        driver.Clear(CLEAR_COLOR | CLEAR_DEPTH);
        
        shader->Bind();
        shader->SetUniformMat4("view", mainCam.GetViewMatrix());
        shader->SetUniformMat4("projection", mainCam.GetProjectionMatrix());
        RenderScene();

        // Desenhar PIP no canto
        glDisable(GL_DEPTH_TEST);
        pipShader->Bind();
        pip->GetTexture("pip")->Bind(0);
        DrawQuad(10, 10, 320, 240);  // Canto inferior esquerdo
        glEnable(GL_DEPTH_TEST);
    }

    delete pip;
}

// ============================================================================
// EXEMPLO COMPLETO: Integrar no teu main.cpp
// ============================================================================

int main()
{
    Device &device = Device::Instance();
    device.Create(1024, 768, "Render to Texture", true, 1);
    
    Driver &driver = Driver::Instance();
    
    // Carregar assets
    Mesh *cube = MeshManager::Instance().CreateCube("cube");
    Shader *shader = ShaderManager::Instance().Create("basic", vertexShader, fragmentShader);
    
    // CRIAR RENDER TARGET
    RenderTarget *offscreen = new RenderTarget(512, 512);
    offscreen->AddColorAttachment(TextureFormat::RGBA8, "color");
    offscreen->AddDepthAttachment(TextureFormat::DEPTH24);
    offscreen->Build();
    
    Camera camera(CameraType::PERSPECTIVE, CameraMode::FIRST_PERSON);
    camera.SetPerspective(45.0f, 1.0f, 0.1f, 100.0f);  // aspect 1:1 para textura quadrada
    camera.SetPosition(glm::vec3(0, 0, 5));
    
    QuadRenderer quad;  // Para desenhar a textura

    while (device.IsRunning())
    {
        // Input/Update...
        
        // ========================================
        // PASS 1: Render para textura offscreen
        // ========================================
        offscreen->Bind();
        offscreen->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        shader->Bind();
        shader->SetUniformMat4("view", camera.GetViewMatrix());
        shader->SetUniformMat4("projection", camera.GetProjectionMatrix());
        
        glm::mat4 model = glm::rotate(glm::mat4(1.0f), 
                                      (float)glfwGetTime(), 
                                      glm::vec3(0, 1, 0));
        shader->SetUniformMat4("model", &model[0][0]);
        
        cube->Render();
        
        offscreen->Unbind();
        
        // ========================================
        // PASS 2: Render para o ecrã
        // ========================================
        RenderTarget::BindDefault();
        driver.SetViewPort(0, 0, 1024, 768);
        driver.Clear(CLEAR_COLOR | CLEAR_DEPTH);
        
        // Desenhar um quad fullscreen com a textura gerada
        glDisable(GL_DEPTH_TEST);
        
        Shader *texShader = ShaderManager::Instance().Get("texture");
        texShader->Bind();
        texShader->SetUniform("tex", 0);
        
        offscreen->GetTexture("color")->Bind(0);
        
        quad.render();
        
        glEnable(GL_DEPTH_TEST);
        
        device.Flip();
    }
    
    // Cleanup
    delete offscreen;
    quad.relase();
    MeshManager::Instance().UnloadAll();
    ShaderManager::Instance().UnloadAll();
    device.Close();
    
    return 0;
}
