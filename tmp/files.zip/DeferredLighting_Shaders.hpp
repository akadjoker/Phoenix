// ============================================================================
// SHADERS: DEFERRED LIGHTING com Light Volumes
// ============================================================================

// ============================================================================
// 1. GBUFFER SHADER
// ============================================================================

const char* deferredGBufferVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoords;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoords;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    vec4 worldPos = model * vec4(aPos, 1.0);
    FragPos = worldPos.xyz;
    Normal = mat3(transpose(inverse(model))) * aNormal;
    TexCoords = aTexCoords;
    
    gl_Position = projection * view * worldPos;
}
)";

const char* deferredGBufferFS = R"(
#version 300 es
precision highp float;

layout (location = 0) out vec3 gPosition;
layout (location = 1) out vec3 gNormal;
layout (location = 2) out vec4 gAlbedoSpec;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;

uniform sampler2D texture_diffuse;
uniform float specular; // 0.0 - 1.0

void main()
{    
    gPosition = FragPos;
    gNormal = normalize(Normal);
    gAlbedoSpec.rgb = texture(texture_diffuse, TexCoords).rgb;
    gAlbedoSpec.a = specular;
}
)";

// ============================================================================
// 2. POINT LIGHT SHADER (Light Volume)
// ============================================================================

const char* pointLightVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0);
}
)";

const char* pointLightFS = R"(
#version 300 es
precision highp float;

out vec4 FragColor;

uniform sampler2D gPosition;
uniform sampler2D gNormal;
uniform sampler2D gAlbedoSpec;

uniform vec3 lightPos;
uniform vec3 lightColor;
uniform float lightRadius;
uniform float lightIntensity;
uniform vec3 viewPos;
uniform vec2 screenSize;

void main()
{
    // Calcular TexCoords do pixel atual
    vec2 TexCoords = gl_FragCoord.xy / screenSize;
    
    // Ler GBuffer
    vec3 FragPos = texture(gPosition, TexCoords).rgb;
    vec3 Normal = texture(gNormal, TexCoords).rgb;
    vec4 AlbedoSpec = texture(gAlbedoSpec, TexCoords);
    vec3 Albedo = AlbedoSpec.rgb;
    float Specular = AlbedoSpec.a;
    
    // Calcular lighting
    vec3 lightDir = lightPos - FragPos;
    float distance = length(lightDir);
    
    // Atenuação
    if (distance > lightRadius)
    {
        discard; // Fora do alcance
    }
    
    lightDir = normalize(lightDir);
    
    // Atenuação quadrática
    float attenuation = 1.0 - (distance / lightRadius);
    attenuation = attenuation * attenuation;
    
    // Diffuse
    float diff = max(dot(Normal, lightDir), 0.0);
    vec3 diffuse = diff * Albedo;
    
    // Specular (Blinn-Phong)
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float spec = pow(max(dot(Normal, halfwayDir), 0.0), 32.0);
    vec3 specular = spec * Specular * lightColor;
    
    // Combinar
    vec3 lighting = (diffuse + specular) * lightColor * lightIntensity * attenuation;
    
    FragColor = vec4(lighting, 1.0);
}
)";

// ============================================================================
// 3. SPOT LIGHT SHADER (Light Volume)
// ============================================================================

const char* spotLightVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0);
}
)";

const char* spotLightFS = R"(
#version 300 es
precision highp float;

out vec4 FragColor;

uniform sampler2D gPosition;
uniform sampler2D gNormal;
uniform sampler2D gAlbedoSpec;

uniform vec3 lightPos;
uniform vec3 lightDir;
uniform vec3 lightColor;
uniform float lightRadius;
uniform float lightIntensity;
uniform float innerCone;  // cos do ângulo interno
uniform float outerCone;  // cos do ângulo externo
uniform vec3 viewPos;
uniform vec2 screenSize;

void main()
{
    vec2 TexCoords = gl_FragCoord.xy / screenSize;
    
    vec3 FragPos = texture(gPosition, TexCoords).rgb;
    vec3 Normal = texture(gNormal, TexCoords).rgb;
    vec4 AlbedoSpec = texture(gAlbedoSpec, TexCoords);
    vec3 Albedo = AlbedoSpec.rgb;
    float Specular = AlbedoSpec.a;
    
    vec3 lightToFrag = FragPos - lightPos;
    float distance = length(lightToFrag);
    
    if (distance > lightRadius)
    {
        discard;
    }
    
    vec3 lightToFragDir = normalize(lightToFrag);
    
    // Spotlight cone
    float theta = dot(lightToFragDir, normalize(lightDir));
    float epsilon = innerCone - outerCone;
    float intensity = clamp((theta - outerCone) / epsilon, 0.0, 1.0);
    
    if (intensity <= 0.0)
    {
        discard;
    }
    
    // Atenuação
    float attenuation = 1.0 - (distance / lightRadius);
    attenuation = attenuation * attenuation;
    
    // Lighting
    vec3 L = -lightToFragDir;
    float diff = max(dot(Normal, L), 0.0);
    vec3 diffuse = diff * Albedo;
    
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 halfwayDir = normalize(L + viewDir);
    float spec = pow(max(dot(Normal, halfwayDir), 0.0), 32.0);
    vec3 specular = spec * Specular * lightColor;
    
    vec3 lighting = (diffuse + specular) * lightColor * lightIntensity * attenuation * intensity;
    
    FragColor = vec4(lighting, 1.0);
}
)";

// ============================================================================
// 4. AMBIENT PASS (simples)
// ============================================================================

const char* ambientVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoords;

out vec2 TexCoords;

void main()
{
    TexCoords = aTexCoords;
    gl_Position = vec4(aPos, 1.0);
}
)";

const char* ambientFS = R"(
#version 300 es
precision highp float;

out vec4 FragColor;

in vec2 TexCoords;

uniform sampler2D gAlbedoSpec;
uniform vec3 ambientColor;
uniform float ambientStrength;

void main()
{
    vec3 Albedo = texture(gAlbedoSpec, TexCoords).rgb;
    vec3 ambient = Albedo * ambientColor * ambientStrength;
    FragColor = vec4(ambient, 1.0);
}
)";
