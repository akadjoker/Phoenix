// ============================================================================
// DEFERRED LIGHTING - Light Volumes
// Para ambientes indoor com MUITAS luzes (Quake/Doom style)
// ============================================================================

#pragma once

#include "RenderTarget.hpp"
#include "Transform.hpp"
#include <vector>

// ============================================================================
// ESTRUTURAS DE LUZ (usando Transform)
// ============================================================================

struct PointLight
{
    Transform transform;
    Vec3 color;
    float radius;      
    float intensity;
    
    PointLight() : color(1,1,1), radius(10.0f), intensity(1.0f) {}
    
    PointLight(Vec3 pos, Vec3 col, float rad, float intens = 1.0f)
        : color(col), radius(rad), intensity(intens)
    {
        transform.setPosition(pos);
    }
    
    Vec3 GetPosition() { return transform.getPosition(); }
    void SetPosition(const Vec3& pos) { transform.setPosition(pos); }
    void Move(const Vec3& offset) { transform.translate(offset); }
};

struct SpotLight
{
    Transform transform;
    Vec3 color;
    float radius;
    float innerCone;   // graus
    float outerCone;   // graus
    float intensity;
    
    SpotLight() : color(1,1,1), radius(15.0f), innerCone(15.0f), 
                  outerCone(25.0f), intensity(1.0f)
    {
        transform.setRotation(-90, 0, 0); // Aponta para baixo
    }
    
    Vec3 GetPosition() { return transform.getPosition(); }
    Vec3 GetDirection() { return transform.forward(); }
    
    void SetPosition(const Vec3& pos) { transform.setPosition(pos); }
    void LookAt(const Vec3& target) { transform.lookAt(target); }
    void Rotate(float pitch, float yaw) { transform.rotate(pitch, yaw, 0); }
};

// ============================================================================
// DEFERRED LIGHTING PIPELINE
// ============================================================================

class DeferredLighting
{
private:
    RenderTarget *gbuffer;
    RenderTarget *lightBuffer;
    
    Mesh *sphereMesh;      
    Mesh *coneMesh;        
    
    std::vector<PointLight> pointLights;
    std::vector<SpotLight> spotLights;
    
    u32 width, height;
    
public:
    DeferredLighting(u32 w, u32 h);
    ~DeferredLighting();
    
    // Getters
    RenderTarget* GetGBuffer() { return gbuffer; }
    RenderTarget* GetLightBuffer() { return lightBuffer; }
    Mesh* GetSphereMesh() { return sphereMesh; }
    Mesh* GetConeMesh() { return coneMesh; }
    
    // Gestão de luzes
    void ClearLights();
    void AddPointLight(const PointLight& light);
    void AddSpotLight(const SpotLight& light);
    
    PointLight* GetPointLight(u32 index);
    SpotLight* GetSpotLight(u32 index);
    
    u32 GetPointLightCount() const { return pointLights.size(); }
    u32 GetSpotLightCount() const { return spotLights.size(); }
    
    const std::vector<PointLight>& GetPointLights() const { return pointLights; }
    const std::vector<SpotLight>& GetSpotLights() const { return spotLights; }
    
    // Render passes
    void BeginGBufferPass();
    void EndGBufferPass();
    void BeginLightingPass();
    void EndLightingPass();
    
    void BindGBufferTextures(u32 startSlot = 0);
    
    void Resize(u32 w, u32 h);
    
    // Delete copy
    DeferredLighting(const DeferredLighting&) = delete;
    DeferredLighting& operator=(const DeferredLighting&) = delete;
};
