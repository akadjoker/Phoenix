// ============================================================================
// RENDERING PIPELINE MODERNA
// GBuffer + SSAO + Cascaded Shadows + PBR Lighting + Post-Processing
// ============================================================================

#pragma once

#include "RenderTarget.hpp"
#include "CascadedShadowMap.hpp"

// ============================================================================
// ARQUITETURA: Deferred Rendering com múltiplas técnicas
// ============================================================================
/*
PASSES:
1. Shadow Pass    - Render cascaded shadow maps
2. GBuffer Pass   - Render geometry (position, normal, albedo, roughness/metallic)
3. SSAO Pass      - Screen Space Ambient Occlusion
4. Lighting Pass  - PBR lighting com shadows + SSAO
5. Post Pass      - Bloom, tone mapping, etc

PORQUÊ SEPARAR?
✅ Modular - cada técnica é independente
✅ Performance - deferred é melhor para múltiplas luzes
✅ Flexível - liga/desliga técnicas facilmente
✅ Debug - visualizar cada pass separadamente
✅ Profissional - arquitetura usada em engines AAA
*/

class RenderPipeline
{
private:
    // Render targets
    RenderTarget *gbuffer;           // Position, Normal, Albedo+Roughness, Metallic+AO
    RenderTarget *ssaoBuffer;        // SSAO
    RenderTarget *ssaoBlurBuffer;    // SSAO blurred
    RenderTarget *lightingBuffer;    // Final lighting (HDR)
    RenderTarget *postBuffer;        // Post-processing
    
    CascadedShadowMap *shadowMaps;   // Cascaded shadow maps
    
    // Dimensões
    u32 width;
    u32 height;
    
    // Settings
    bool enableSSAO;
    bool enableShadows;
    bool enableBloom;
    
public:
    RenderPipeline(u32 w, u32 h)
        : width(w), height(h), 
          enableSSAO(true), 
          enableShadows(true), 
          enableBloom(true)
    {
        // ===== 1. GBUFFER (Deferred) =====
        gbuffer = new RenderTarget(width, height);
        gbuffer->AddColorAttachment(TextureFormat::RGB32F, "gPosition");      // World position
        gbuffer->AddColorAttachment(TextureFormat::RGB16F, "gNormal");        // Normal
        gbuffer->AddColorAttachment(TextureFormat::RGBA8, "gAlbedo");         // Albedo + Roughness
        gbuffer->AddColorAttachment(TextureFormat::RG8, "gMetallicAO");       // Metallic + AO
        gbuffer->AddDepthAttachment(TextureFormat::DEPTH24);
        gbuffer->Build();
        
        // ===== 2. SSAO =====
        ssaoBuffer = new RenderTarget(width, height);
        ssaoBuffer->AddColorAttachment(TextureFormat::R8, "ssao");
        ssaoBuffer->Build();
        
        ssaoBlurBuffer = new RenderTarget(width, height);
        ssaoBlurBuffer->AddColorAttachment(TextureFormat::R8, "ssaoBlurred");
        ssaoBlurBuffer->Build();
        
        // ===== 3. LIGHTING (HDR) =====
        lightingBuffer = new RenderTarget(width, height);
        lightingBuffer->AddColorAttachment(TextureFormat::RGBA16F, "hdr");
        lightingBuffer->Build();
        
        // ===== 4. POST-PROCESSING =====
        postBuffer = new RenderTarget(width, height);
        postBuffer->AddColorAttachment(TextureFormat::RGBA8, "final");
        postBuffer->Build();
        
        // ===== 5. SHADOW MAPS =====
        shadowMaps = new CascadedShadowMap(4, 2048, 2048);
        
        LogInfo("[RenderPipeline] Created (%ux%u)", width, height);
    }
    
    ~RenderPipeline()
    {
        delete gbuffer;
        delete ssaoBuffer;
        delete ssaoBlurBuffer;
        delete lightingBuffer;
        delete postBuffer;
        delete shadowMaps;
    }
    
    // ========================================
    // GETTERS
    // ========================================
    
    RenderTarget* GetGBuffer() { return gbuffer; }
    RenderTarget* GetSSAOBuffer() { return ssaoBuffer; }
    RenderTarget* GetSSAOBlurBuffer() { return ssaoBlurBuffer; }
    RenderTarget* GetLightingBuffer() { return lightingBuffer; }
    RenderTarget* GetPostBuffer() { return postBuffer; }
    CascadedShadowMap* GetShadowMaps() { return shadowMaps; }
    
    // ========================================
    // SETTINGS
    // ========================================
    
    void SetSSAO(bool enabled) { enableSSAO = enabled; }
    void SetShadows(bool enabled) { enableShadows = enabled; }
    void SetBloom(bool enabled) { enableBloom = enabled; }
    
    bool IsSSAOEnabled() const { return enableSSAO; }
    bool IsShadowsEnabled() const { return enableShadows; }
    bool IsBloomEnabled() const { return enableBloom; }
    
    // ========================================
    // RESIZE
    // ========================================
    
    void Resize(u32 w, u32 h)
    {
        if (w == width && h == height) return;
        
        width = w;
        height = h;
        
        gbuffer->Resize(w, h);
        ssaoBuffer->Resize(w, h);
        ssaoBlurBuffer->Resize(w, h);
        lightingBuffer->Resize(w, h);
        postBuffer->Resize(w, h);
    }
    
    // ========================================
    // BIND HELPERS
    // ========================================
    
    void BeginShadowPass(u32 cascadeIndex)
    {
        shadowMaps->BindCascade(cascadeIndex);
        shadowMaps->ClearCascade(cascadeIndex);
        glViewport(0, 0, shadowMaps->GetWidth(), shadowMaps->GetHeight());
    }
    
    void EndShadowPass()
    {
        shadowMaps->Unbind();
        glViewport(0, 0, width, height);
    }
    
    void BeginGBufferPass()
    {
        gbuffer->Bind();
        gbuffer->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
    
    void EndGBufferPass()
    {
        gbuffer->Unbind();
    }
    
    void BeginSSAOPass()
    {
        ssaoBuffer->Bind();
        ssaoBuffer->Clear(GL_COLOR_BUFFER_BIT);
    }
    
    void EndSSAOPass()
    {
        ssaoBuffer->Unbind();
    }
    
    void BeginSSAOBlurPass()
    {
        ssaoBlurBuffer->Bind();
        ssaoBlurBuffer->Clear(GL_COLOR_BUFFER_BIT);
    }
    
    void EndSSAOBlurPass()
    {
        ssaoBlurBuffer->Unbind();
    }
    
    void BeginLightingPass()
    {
        lightingBuffer->Bind();
        lightingBuffer->Clear(GL_COLOR_BUFFER_BIT);
    }
    
    void EndLightingPass()
    {
        lightingBuffer->Unbind();
    }
    
    void BeginPostPass()
    {
        postBuffer->Bind();
        postBuffer->Clear(GL_COLOR_BUFFER_BIT);
    }
    
    void EndPostPass()
    {
        postBuffer->Unbind();
    }
    
    // ========================================
    // BIND ALL GBUFFER TEXTURES
    // ========================================
    
    void BindGBufferTextures()
    {
        gbuffer->GetTexture("gPosition")->Bind(0);
        gbuffer->GetTexture("gNormal")->Bind(1);
        gbuffer->GetTexture("gAlbedo")->Bind(2);
        gbuffer->GetTexture("gMetallicAO")->Bind(3);
    }
    
    // Delete copy
    RenderPipeline(const RenderPipeline&) = delete;
    RenderPipeline& operator=(const RenderPipeline&) = delete;
};
