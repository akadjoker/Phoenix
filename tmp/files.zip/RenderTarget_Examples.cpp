// ============================================================================
// EXEMPLO: Como usar a classe RenderTarget
// ============================================================================

#include "RenderTarget.hpp"

// ============================================================================
// ANTES - Código manual do main.cpp
// ============================================================================
void Example_OLD_Way()
{
    // Criar texturas manualmente
    GLuint gPosition, gNormal, gAlbedoSpec;
    glGenTextures(1, &gPosition);
    glGenTextures(1, &gNormal);
    glGenTextures(1, &gAlbedoSpec);

    // Configurar Position
    glBindTexture(GL_TEXTURE_2D, gPosition);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, screenWidth, screenHeight, 0, GL_RGB, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // Configurar Normal
    glBindTexture(GL_TEXTURE_2D, gNormal);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, screenWidth, screenHeight, 0, GL_RGB, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // Configurar Albedo+Spec
    glBindTexture(GL_TEXTURE_2D, gAlbedoSpec);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, screenWidth, screenHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // Criar framebuffer
    GLuint gBuffer;
    glGenFramebuffers(1, &gBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, gBuffer);

    // Attach texturas
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, gPosition, 0);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, GL_TEXTURE_2D, gNormal, 0);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT2, GL_TEXTURE_2D, gAlbedoSpec, 0);

    // Configurar draw buffers
    unsigned int attachments[3] = {GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2};
    glDrawBuffers(3, attachments);

    // Criar depth buffer
    GLuint rboDepth;
    glGenRenderbuffers(1, &rboDepth);
    glBindRenderbuffer(GL_RENDERBUFFER, rboDepth);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, screenWidth, screenHeight);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rboDepth);

    // Verificar
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        LogError("ERROR::FRAMEBUFFER:: Framebuffer is not complete!");
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // ... código de rendering ...

    // No final - cleanup manual
    glDeleteFramebuffers(1, &gBuffer);
    glDeleteTextures(1, &gPosition);
    glDeleteTextures(1, &gNormal);
    glDeleteTextures(1, &gAlbedoSpec);
    glDeleteRenderbuffers(1, &rboDepth);
}

// ============================================================================
// AGORA - Usando a classe RenderTarget
// ============================================================================
void Example_NEW_Way()
{
    // Opção 1: Usar factory (mais rápido)
    RenderTarget *gbuffer = RenderTargetFactory::CreateGBuffer(screenWidth, screenHeight);

    // Opção 2: Criar customizado
    RenderTarget *customBuffer = new RenderTarget(screenWidth, screenHeight);
    customBuffer->AddColorAttachment(TextureFormat::RGB16F, "position");
    customBuffer->AddColorAttachment(TextureFormat::RGB16F, "normal");
    customBuffer->AddColorAttachment(TextureFormat::RGBA8, "albedo");
    customBuffer->AddDepthAttachment(TextureFormat::DEPTH24, false); // renderbuffer
    customBuffer->Build();

    // USAR NO RENDERING
    // Geometry pass
    gbuffer->Bind();
    gbuffer->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    shaderGeometryPass->Bind();
    // ... render geometria ...
    
    gbuffer->Unbind();

    // Lighting pass
    RenderTarget::BindDefault();
    
    shaderLightingPass->Bind();
    shaderLightingPass->SetUniform("gPosition", 0);
    shaderLightingPass->SetUniform("gNormal", 1);
    shaderLightingPass->SetUniform("gAlbedoSpec", 2);
    
    // Bind texturas do GBuffer
    gbuffer->GetTexture("gPosition")->Bind(0);
    gbuffer->GetTexture("gNormal")->Bind(1);
    gbuffer->GetTexture("gAlbedoSpec")->Bind(2);
    
    // ou usando índice
    // gbuffer->GetTexture(0)->Bind(0);
    // gbuffer->GetTexture(1)->Bind(1);
    // gbuffer->GetTexture(2)->Bind(2);
    
    quad.render();

    // Cleanup automático no destrutor!
    delete gbuffer;
    delete customBuffer;
}

// ============================================================================
// EXEMPLO: Shadow Mapping
// ============================================================================
void Example_ShadowMapping()
{
    RenderTarget *shadowMap = RenderTargetFactory::CreateShadowMap(2048, 2048);

    // Render shadow pass
    shadowMap->Bind();
    shadowMap->Clear(GL_DEPTH_BUFFER_BIT);
    
    shadowShader->Bind();
    // ... render cena da perspectiva da luz ...
    
    shadowMap->Unbind();

    // Usar shadow map
    RenderTarget::BindDefault();
    mainShader->Bind();
    shadowMap->GetDepthTexture()->Bind(5);
    mainShader->SetUniform("shadowMap", 5);
    
    // ... render cena normal ...

    delete shadowMap;
}

// ============================================================================
// EXEMPLO: Água com reflection e refraction
// ============================================================================
void Example_Water()
{
    RenderTarget *reflection = RenderTargetFactory::CreateWaterReflection(1024, 768);
    RenderTarget *refraction = RenderTargetFactory::CreateWaterRefraction(1024, 768);

    // Render reflection (câmera invertida)
    reflection->Bind();
    reflection->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // ... render cena com câmera invertida ...
    reflection->Unbind();

    // Render refraction
    refraction->Bind();
    refraction->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // ... render cena abaixo da água ...
    refraction->Unbind();

    // Render água com as texturas
    RenderTarget::BindDefault();
    waterShader->Bind();
    reflection->GetTexture("reflection")->Bind(0);
    refraction->GetTexture("refraction")->Bind(1);
    waterShader->SetUniform("reflectionTexture", 0);
    waterShader->SetUniform("refractionTexture", 1);
    // ... render plano de água ...

    delete reflection;
    delete refraction;
}

// ============================================================================
// EXEMPLO: HDR + Post-processing
// ============================================================================
void Example_HDR_PostProcessing()
{
    RenderTarget *hdrBuffer = RenderTargetFactory::CreateHDR(screenWidth, screenHeight);
    RenderTarget *pingpong[2] = {
        RenderTargetFactory::CreatePostProcess(screenWidth, screenHeight),
        RenderTargetFactory::CreatePostProcess(screenWidth, screenHeight)
    };

    // Render cena em HDR
    hdrBuffer->Bind();
    hdrBuffer->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // ... render cena ...
    hdrBuffer->Unbind();

    // Blur horizontal/vertical (ping-pong)
    bool horizontal = true;
    for (int i = 0; i < 10; i++)
    {
        pingpong[horizontal ? 0 : 1]->Bind();
        blurShader->Bind();
        blurShader->SetUniform("horizontal", horizontal);
        
        if (i == 0)
            hdrBuffer->GetTexture(0)->Bind(0);
        else
            pingpong[!horizontal ? 0 : 1]->GetTexture(0)->Bind(0);
        
        quad.render();
        horizontal = !horizontal;
    }

    // Tone mapping final
    RenderTarget::BindDefault();
    toneMappingShader->Bind();
    hdrBuffer->GetTexture(0)->Bind(0);
    pingpong[0]->GetTexture(0)->Bind(1);
    quad.render();

    delete hdrBuffer;
    delete pingpong[0];
    delete pingpong[1];
}

// ============================================================================
// EXEMPLO: Resize quando janela muda
// ============================================================================
void Example_Resize()
{
    RenderTarget *rt = RenderTargetFactory::CreateGBuffer(screenWidth, screenHeight);

    // ... na callback de resize da janela ...
    void OnWindowResize(int newWidth, int newHeight)
    {
        screenWidth = newWidth;
        screenHeight = newHeight;
        
        // Resize automático!
        rt->Resize(newWidth, newHeight);
    }

    delete rt;
}

// ============================================================================
// VANTAGENS DA CLASSE:
// ============================================================================
/*
1. ✅ Código muito mais limpo e legível
2. ✅ Menos erros (verificações automáticas)
3. ✅ Gestão automática de memória
4. ✅ Fácil reutilização com Factory patterns
5. ✅ Integração perfeita com a classe Texture existente
6. ✅ Suporte para resize
7. ✅ Blit operations facilitadas
8. ✅ Debug mais fácil com logging
9. ✅ Zero overhead - mesmo que código manual
10. ✅ Sem smart pointers - performance máxima
*/
