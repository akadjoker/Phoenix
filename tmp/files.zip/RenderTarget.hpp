#pragma once

#include "Texture.hpp"
#include <vector>
#include <string>

enum class AttachmentType
{
    COLOR,
    DEPTH,
    STENCIL,
    DEPTH_STENCIL
};

struct AttachmentConfig
{
    AttachmentType type;
    TextureFormat format;
    bool useTexture;      // true = texture, false = renderbuffer
    FilterMode minFilter;
    FilterMode magFilter;
    WrapMode wrap;
    std::string name;

    AttachmentConfig()
        : type(AttachmentType::COLOR),
          format(TextureFormat::RGBA8),
          useTexture(true),
          minFilter(FilterMode::LINEAR),
          magFilter(FilterMode::LINEAR),
          wrap(WrapMode::CLAMP_TO_EDGE),
          name("attachment") {}
};

class RenderTarget
{
private:
    u32 fbo;
    u32 width;
    u32 height;

    struct Attachment
    {
        Texture *texture;         // Ponteiro para textura (se useTexture = true)
        u32 renderbuffer;        // ID do renderbuffer (se useTexture = false)
        AttachmentType type;
        bool isTexture;
        std::string name;
    };

    std::vector<Attachment> attachments;
    std::vector<u32> colorAttachments; // Para glDrawBuffers

public:
    RenderTarget(u32 w, u32 h);
    ~RenderTarget();

    // Adicionar attachments
    void AddColorAttachment(TextureFormat format = TextureFormat::RGBA8, 
                           const std::string &name = "color", 
                           bool useTexture = true);
    
    void AddDepthAttachment(TextureFormat format = TextureFormat::DEPTH24, 
                           bool useTexture = true);
    
    void AddDepthStencilAttachment(bool useTexture = true);
    
    // Configuração customizada
    void AddAttachment(const AttachmentConfig &config);

    // Finalizar configuração (obrigatório após adicionar attachments)
    bool Build();

    // Binding
    void Bind();
    void Unbind();
    static void BindDefault();

    // Obter texturas
    Texture *GetTexture(const std::string &name) const;
    Texture *GetTexture(u32 index) const;
    Texture *GetDepthTexture() const;
    u32 GetTextureID(u32 index) const;

    // Utilitários
    u32 GetWidth() const { return width; }
    u32 GetHeight() const { return height; }
    void Resize(u32 w, u32 h);
    void Clear(u32 mask = GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Verificação
    bool IsComplete() const;
    const char *GetStatusString() const;

    // Blit operations
    void BlitDepthTo(RenderTarget *target);
    void BlitColorTo(RenderTarget *target, u32 srcIndex = 0, u32 dstIndex = 0);

    // Delete copy
    RenderTarget(const RenderTarget &) = delete;
    RenderTarget &operator=(const RenderTarget &) = delete;
};

// ============================================================================
// FACTORY - Pré-configurações comuns
// ============================================================================

namespace RenderTargetFactory
{
    // GBuffer para Deferred Rendering (Position, Normal, Albedo+Spec)
    RenderTarget *CreateGBuffer(u32 width, u32 height);

    // Shadow Map (depth only)
    RenderTarget *CreateShadowMap(u32 width, u32 height);

    // Reflection/Refraction para água
    RenderTarget *CreateWaterReflection(u32 width, u32 height);
    RenderTarget *CreateWaterRefraction(u32 width, u32 height);

    // HDR Framebuffer
    RenderTarget *CreateHDR(u32 width, u32 height);

    // Post-processing simples (color + depth)
    RenderTarget *CreatePostProcess(u32 width, u32 height);

    // Screen Space buffer (para SSAO)
    RenderTarget *CreateSSAO(u32 width, u32 height);
}
