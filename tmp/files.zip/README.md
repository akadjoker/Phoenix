# RenderTarget - Classe para Framebuffers OpenGL

Classe utilitária para simplificar a criação e gestão de framebuffers OpenGL. Integra-se perfeitamente com a tua classe `Texture` existente.

## 📦 Ficheiros

- `RenderTarget.hpp` - Header da classe
- `RenderTarget.cpp` - Implementação
- `RenderTarget_Examples.cpp` - Exemplos de uso

## 🎯 Características

✅ **Simples e eficiente** - Zero overhead comparado com código manual  
✅ **Gestão automática** - Cleanup automático de recursos  
✅ **Factory patterns** - Configurações pré-definidas para casos comuns  
✅ **Integração perfeita** - Usa a tua classe `Texture` existente  
✅ **Sem smart pointers** - Performance máxima para jogos  
✅ **Resize support** - Fácil adaptação a mudanças de resolução  

## 🚀 Uso Básico

### 1. GBuffer (Deferred Rendering)

```cpp
// Em vez de criar tudo manualmente...
RenderTarget *gbuffer = RenderTargetFactory::CreateGBuffer(1024, 768);

// Usar
gbuffer->Bind();
gbuffer->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
// ... render geometria ...
gbuffer->Unbind();

// Aceder às texturas
gbuffer->GetTexture("gPosition")->Bind(0);
gbuffer->GetTexture("gNormal")->Bind(1);
gbuffer->GetTexture("gAlbedoSpec")->Bind(2);

// Cleanup
delete gbuffer;
```

### 2. Shadow Map

```cpp
RenderTarget *shadowMap = RenderTargetFactory::CreateShadowMap(2048, 2048);

shadowMap->Bind();
shadowMap->Clear(GL_DEPTH_BUFFER_BIT);
// ... render da perspectiva da luz ...
shadowMap->Unbind();

// Usar
shadowMap->GetDepthTexture()->Bind(5);
```

### 3. Água (Reflection + Refraction)

```cpp
RenderTarget *reflection = RenderTargetFactory::CreateWaterReflection(1024, 768);
RenderTarget *refraction = RenderTargetFactory::CreateWaterRefraction(1024, 768);

// Render reflection
reflection->Bind();
// ... render com câmera invertida ...

// Render refraction
refraction->Bind();
// ... render abaixo da água ...

// Usar nas texturas da água
reflection->GetTexture("reflection")->Bind(0);
refraction->GetTexture("refraction")->Bind(1);
```

### 4. Customizado

```cpp
RenderTarget *custom = new RenderTarget(width, height);

// Adicionar attachments manualmente
custom->AddColorAttachment(TextureFormat::RGBA16F, "color1");
custom->AddColorAttachment(TextureFormat::RGB32F, "color2");
custom->AddDepthAttachment(TextureFormat::DEPTH24);

// IMPORTANTE: Chamar Build() no final!
if (!custom->Build())
{
    LogError("Failed to build framebuffer!");
    delete custom;
    return;
}

// Usar...
custom->Bind();
// ...
```

## 🏭 Factory Methods Disponíveis

```cpp
// GBuffer para Deferred Rendering (Position + Normal + Albedo+Spec + Depth)
RenderTarget* CreateGBuffer(u32 width, u32 height);

// Shadow Map (apenas depth texture)
RenderTarget* CreateShadowMap(u32 width, u32 height);

// Reflection/Refraction para água
RenderTarget* CreateWaterReflection(u32 width, u32 height);
RenderTarget* CreateWaterRefraction(u32 width, u32 height);

// HDR Framebuffer (RGBA16F + Depth)
RenderTarget* CreateHDR(u32 width, u32 height);

// Post-processing simples (RGBA8 + Depth)
RenderTarget* CreatePostProcess(u32 width, u32 height);

// SSAO buffer (R8)
RenderTarget* CreateSSAO(u32 width, u32 height);
```

## 🔧 API Principal

### Construção

```cpp
RenderTarget(u32 width, u32 height);

// Adicionar attachments
void AddColorAttachment(TextureFormat format, const std::string &name, bool useTexture = true);
void AddDepthAttachment(TextureFormat format, bool useTexture = true);
void AddDepthStencilAttachment(bool useTexture = true);

// Finalizar (OBRIGATÓRIO)
bool Build();
```

### Rendering

```cpp
void Bind();                              // Bind framebuffer + set viewport
void Unbind();                           // Unbind framebuffer
static void BindDefault();               // Bind default framebuffer (0)
void Clear(u32 mask = GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
```

### Acesso às Texturas

```cpp
Texture* GetTexture(const std::string &name) const;  // Por nome
Texture* GetTexture(u32 index) const;                // Por índice de cor
Texture* GetDepthTexture() const;                    // Depth texture
u32 GetTextureID(u32 index) const;                   // ID direto
```

### Utilitários

```cpp
u32 GetWidth() const;
u32 GetHeight() const;
void Resize(u32 w, u32 h);               // Resize automático
bool IsComplete() const;                 // Verificar status
const char* GetStatusString() const;     // Mensagem de erro
```

### Blit Operations

```cpp
void BlitDepthTo(RenderTarget *target);
void BlitColorTo(RenderTarget *target, u32 srcIndex = 0, u32 dstIndex = 0);
```

## 📝 Comparação: Antes vs Depois

### ANTES (Código manual do teu main.cpp)
```cpp
// ~50 linhas de código repetitivo
GLuint gPosition, gNormal, gAlbedoSpec;
glGenTextures(1, &gPosition);
glGenTextures(1, &gNormal);
glGenTextures(1, &gAlbedoSpec);

glBindTexture(GL_TEXTURE_2D, gPosition);
glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB16F, width, height, 0, GL_RGB, GL_FLOAT, NULL);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
// ... mais 40 linhas ...

// Cleanup manual no final
glDeleteFramebuffers(1, &gBuffer);
glDeleteTextures(1, &gPosition);
// ...
```

### DEPOIS (Com RenderTarget)
```cpp
// 1 linha!
RenderTarget *gbuffer = RenderTargetFactory::CreateGBuffer(width, height);

// Cleanup automático
delete gbuffer;
```

## 🎨 Exemplos Completos

Vê o ficheiro `RenderTarget_Examples.cpp` para exemplos completos de:
- GBuffer / Deferred Rendering
- Shadow Mapping
- Água com Reflection/Refraction
- HDR + Post-processing
- Resize handling

## ⚙️ Integração

1. Adiciona `RenderTarget.hpp` e `RenderTarget.cpp` ao teu projeto
2. Certifica-te que incluis `Texture.hpp`
3. Usa! Não há dependências extra

## 💡 Dicas

1. **Sempre chama Build()** depois de adicionar attachments:
   ```cpp
   rt->AddColorAttachment(...);
   rt->AddDepthAttachment(...);
   if (!rt->Build()) { /* erro */ }
   ```

2. **Factory é teu amigo** - usa para casos comuns:
   ```cpp
   auto gbuffer = RenderTargetFactory::CreateGBuffer(w, h);
   ```

3. **Textures vs Renderbuffers**:
   - `useTexture = true` → podes fazer sampling depois
   - `useTexture = false` → só para renderizar (mais rápido)

4. **Resize é fácil**:
   ```cpp
   void OnWindowResize(int w, int h) {
       renderTarget->Resize(w, h);
   }
   ```

5. **Debug** - verifica sempre o status:
   ```cpp
   if (!rt->IsComplete())
       LogError("FBO Error: %s", rt->GetStatusString());
   ```

## 🐛 Troubleshooting

**Framebuffer incompleto?**
- Verifica que chamaste `Build()` no final
- Verifica que os formatos são suportados
- Usa `GetStatusString()` para ver o erro

**Texturas não aparecem?**
- Certifica-te que fazes `Bind()` antes de renderizar
- Verifica que as texturas estão bound nas slots certas
- Usa `glGetError()` para debug

**Performance?**
- Usa renderbuffers para attachments que não precisas de sample
- Considera formatos mais leves (RGB8 em vez de RGB16F quando possível)
- Reutiliza RenderTargets quando possível

## 📄 Licença

Usa como quiseres! 🚀
