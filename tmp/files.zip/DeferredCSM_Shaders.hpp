// ============================================================================
// SHADERS: DEFERRED + CASCADED SHADOWS
// ============================================================================

// ============================================================================
// 1. SHADOW DEPTH SHADER (para as cascatas)
// ============================================================================

const char* shadowDepthVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;

uniform mat4 lightSpaceMatrix;
uniform mat4 model;

void main()
{
    gl_Position = lightSpaceMatrix * model * vec4(aPos, 1.0);
}
)";

const char* shadowDepthFS = R"(
#version 300 es
precision highp float;

void main()
{
    // Depth é escrito automaticamente
}
)";

// ============================================================================
// 2. GBUFFER SHADER (geometry pass)
// ============================================================================

const char* gbufferVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoords;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoords;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    vec4 worldPos = model * vec4(aPos, 1.0);
    FragPos = worldPos.xyz;
    Normal = mat3(transpose(inverse(model))) * aNormal;
    TexCoords = aTexCoords;
    
    gl_Position = projection * view * worldPos;
}
)";

const char* gbufferFS = R"(
#version 300 es
precision highp float;

layout (location = 0) out vec3 gPosition;
layout (location = 1) out vec3 gNormal;
layout (location = 2) out vec4 gAlbedo;

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoords;

uniform sampler2D texture_diffuse;

void main()
{    
    gPosition = FragPos;
    gNormal = normalize(Normal);
    gAlbedo.rgb = texture(texture_diffuse, TexCoords).rgb;
    gAlbedo.a = 1.0; // Pode guardar specular aqui
}
)";

// ============================================================================
// 3. DEFERRED LIGHTING SHADER (com Cascaded Shadows!)
// ============================================================================

const char* deferredLightingVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoords;

out vec2 TexCoords;

void main()
{
    TexCoords = aTexCoords;
    gl_Position = vec4(aPos, 1.0);
}
)";

const char* deferredLightingFS = R"(
#version 300 es
precision highp float;

out vec4 FragColor;

in vec2 TexCoords;

// GBuffer
uniform sampler2D gPosition;
uniform sampler2D gNormal;
uniform sampler2D gAlbedo;

// Cascaded Shadow Maps (4 cascatas)
uniform sampler2D shadowMap[4];

// Lighting
uniform vec3 lightDir;
uniform vec3 lightColor;
uniform vec3 viewPos;

// Cascaded Shadow Data
uniform mat4 lightSpaceMatrices[4];
uniform float cascadePlaneDistances[4];
uniform int cascadeCount;
uniform mat4 view;

// Shadow calculation com PCF
float ShadowCalculation(vec3 fragPos, vec3 normal)
{
    // Calcular em qual cascade estamos
    vec4 fragPosViewSpace = view * vec4(fragPos, 1.0);
    float depthValue = abs(fragPosViewSpace.z);
    
    int layer = -1;
    for (int i = 0; i < cascadeCount; ++i)
    {
        if (depthValue < cascadePlaneDistances[i])
        {
            layer = i;
            break;
        }
    }
    if (layer == -1)
        layer = cascadeCount - 1;
    
    // Transform para light space
    vec4 fragPosLightSpace = lightSpaceMatrices[layer] * vec4(fragPos, 1.0);
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;
    
    if (projCoords.z > 1.0)
        return 0.0;
    
    float currentDepth = projCoords.z;
    
    // Bias dinâmico
    float bias = max(0.05 * (1.0 - dot(normal, -lightDir)), 0.005);
    
    // PCF (Percentage Closer Filtering)
    float shadow = 0.0;
    vec2 texelSize = 1.0 / vec2(textureSize(shadowMap[layer], 0));
    
    for(int x = -1; x <= 1; ++x)
    {
        for(int y = -1; y <= 1; ++y)
        {
            vec2 offset = vec2(float(x), float(y)) * texelSize;
            float pcfDepth;
            
            // GLSL ES não permite indexar array dinamicamente
            // então fazemos if/else
            if (layer == 0)
                pcfDepth = texture(shadowMap[0], projCoords.xy + offset).r;
            else if (layer == 1)
                pcfDepth = texture(shadowMap[1], projCoords.xy + offset).r;
            else if (layer == 2)
                pcfDepth = texture(shadowMap[2], projCoords.xy + offset).r;
            else
                pcfDepth = texture(shadowMap[3], projCoords.xy + offset).r;
            
            shadow += currentDepth - bias > pcfDepth ? 1.0 : 0.0;
        }    
    }
    shadow /= 9.0;
    
    return shadow;
}

void main()
{
    // Ler GBuffer
    vec3 FragPos = texture(gPosition, TexCoords).rgb;
    vec3 Normal = texture(gNormal, TexCoords).rgb;
    vec3 Albedo = texture(gAlbedo, TexCoords).rgb;
    
    // Lighting
    vec3 ambient = 0.15 * Albedo;
    
    // Diffuse
    vec3 lightDir_norm = normalize(-lightDir);
    float diff = max(dot(Normal, lightDir_norm), 0.0);
    vec3 diffuse = diff * lightColor * Albedo;
    
    // Specular
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 halfwayDir = normalize(lightDir_norm + viewDir);
    float spec = pow(max(dot(Normal, halfwayDir), 0.0), 32.0);
    vec3 specular = spec * lightColor;
    
    // Shadow
    float shadow = ShadowCalculation(FragPos, Normal);
    
    // Combinar
    vec3 lighting = ambient + (1.0 - shadow) * (diffuse + specular);
    
    FragColor = vec4(lighting, 1.0);
}
)";

// ============================================================================
// 4. DEBUG SHADER (visualizar depth maps)
// ============================================================================

const char* debugDepthVS = R"(
#version 300 es
precision highp float;

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoords;

out vec2 TexCoords;

void main()
{
    TexCoords = aTexCoords;
    gl_Position = vec4(aPos, 1.0);
}
)";

const char* debugDepthFS = R"(
#version 300 es
precision highp float;

out vec4 FragColor;

in vec2 TexCoords;

uniform sampler2D depthMap;
uniform float nearPlane;
uniform float farPlane;

float LinearizeDepth(float depth)
{
    float z = depth * 2.0 - 1.0;
    return (2.0 * nearPlane * farPlane) / (farPlane + nearPlane - z * (farPlane - nearPlane));
}

void main()
{
    float depthValue = texture(depthMap, TexCoords).r;
    // depthValue = LinearizeDepth(depthValue) / farPlane; // para perspectiva
    FragColor = vec4(vec3(depthValue), 1.0);
}
)";
