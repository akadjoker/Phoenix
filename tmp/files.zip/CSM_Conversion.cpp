// ============================================================================
// CONVERSÃO: Cascaded Shadow Maps
// Do código manual para a classe CascadedShadowMap
// ============================================================================

#include "CascadedShadowMap.hpp"

// ============================================================================
// ANTES - Linhas 540-572 do teu main.cpp
// ============================================================================
void OLD_CSM_Code()
{
    const int CASCADE_COUNT = 4;
    const unsigned int SHADOW_WIDTH = 2048;
    const unsigned int SHADOW_HEIGHT = 2048;
    
    // Criar arrays manualmente
    GLuint depthMapFBO[CASCADE_COUNT];
    GLuint depthMaps[CASCADE_COUNT];
    GLuint dummyColors[CASCADE_COUNT];

    glGenFramebuffers(CASCADE_COUNT, depthMapFBO);
    glGenTextures(CASCADE_COUNT, depthMaps);
    glGenTextures(CASCADE_COUNT, dummyColors);

    // Configurar cada cascata manualmente (muito código repetitivo!)
    for (int i = 0; i < CASCADE_COUNT; i++)
    {
        // Depth texture
        glBindTexture(GL_TEXTURE_2D, depthMaps[i]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, SHADOW_WIDTH, SHADOW_HEIGHT, 0,
                     GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
        float borderColor[] = {1.0f, 1.0f, 1.0f, 1.0f};
        glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor);

        // Dummy color attachment
        glBindTexture(GL_TEXTURE_2D, dummyColors[i]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, SHADOW_WIDTH, SHADOW_HEIGHT, 0,
                     GL_RGBA, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

        // Framebuffer
        glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, dummyColors[i], 0);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depthMaps[i], 0);

        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
            LogError("ERROR::FRAMEBUFFER:: Cascade %d framebuffer is not complete!", i);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    
    // ... no loop de render (linhas 717-743) ...
    
    // Renderizar cada cascata
    for (int cascade = 0; cascade < CASCADE_COUNT; ++cascade)
    {
        glBindFramebuffer(GL_FRAMEBUFFER, depthMapFBO[cascade]);
        glClear(GL_DEPTH_BUFFER_BIT);
        
        simpleDepthShader->SetUniformMat4("lightSpaceMatrix", lightSpaceMatrices[cascade].m);
        
        // Render scene
        for (int i = 0; i < 10; i++)
        {
            model = Mat4::Translation(cubePositions[i]);
            simpleDepthShader->SetUniformMat4("model", model.m);
            cube->Render();
        }
    }
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    
    // ... depois, bind texturas para usar (linhas 768-773) ...
    
    for (int i = 0; i < CASCADE_COUNT; ++i)
    {
        std::string uniformName = "shadowMap[" + std::to_string(i) + "]";
        shader->SetTexture2D(uniformName.c_str(), depthMaps[i], 1 + i);
    }
    
    // Cleanup manual no final...
    glDeleteFramebuffers(CASCADE_COUNT, depthMapFBO);
    glDeleteTextures(CASCADE_COUNT, depthMaps);
    glDeleteTextures(CASCADE_COUNT, dummyColors);
}

// ============================================================================
// AGORA - Usando CascadedShadowMap
// ============================================================================
void NEW_CSM_Code()
{
    const int CASCADE_COUNT = 4;
    const unsigned int SHADOW_WIDTH = 2048;
    const unsigned int SHADOW_HEIGHT = 2048;
    
    // 1 LINHA EM VEZ DE 50+!
    CascadedShadowMap *csm = new CascadedShadowMap(CASCADE_COUNT, SHADOW_WIDTH, SHADOW_HEIGHT);
    
    // ... no loop de render ...
    
    // Calcular splits
    float nearPlane = 0.1f;
    float farPlane = 800.0f;
    csm->CalculateSplits(nearPlane, farPlane);
    const auto& splits = csm->GetSplits();
    
    // Renderizar cada cascata (MUITO MAIS LIMPO!)
    simpleDepthShader->Bind();
    glViewport(0, 0, SHADOW_WIDTH, SHADOW_HEIGHT);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);
    
    for (int cascade = 0; cascade < CASCADE_COUNT; ++cascade)
    {
        csm->BindCascade(cascade);        // Bind
        csm->ClearCascade(cascade);       // Clear
        
        simpleDepthShader->SetUniformMat4("lightSpaceMatrix", lightSpaceMatrices[cascade].m);
        
        // Render scene
        for (int i = 0; i < 10; i++)
        {
            model = Mat4::Translation(cubePositions[i]);
            simpleDepthShader->SetUniformMat4("model", model.m);
            cube->Render();
        }
    }
    
    glCullFace(GL_BACK);
    csm->Unbind();
    glViewport(0, 0, screenWidth, screenHeight);
    
    // Bind todas as texturas de uma vez!
    csm->BindAllTextures(1);  // Slots 1, 2, 3, 4
    
    // Ou individualmente se preferires
    // for (int i = 0; i < CASCADE_COUNT; ++i)
    // {
    //     std::string uniformName = "shadowMap[" + std::to_string(i) + "]";
    //     shader->SetTexture2D(uniformName.c_str(), csm->GetDepthTexture(i), 1 + i);
    // }
    
    // Cleanup automático!
    delete csm;
}

// ============================================================================
// CÓDIGO COMPLETO CONVERTIDO
// ============================================================================

int main()
{
    Device &device = Device::Instance();
    if (!device.Create(1024, 768, "CSM Demo", true, 1))
        return 1;

    Driver &driver = Driver::Instance();
    driver.SetClearDepth(1.0f);
    driver.SetClearColor(0.2f, 0.3f, 0.3f, 1.0f);

    // Setup
    TextureManager::Instance().Init();
    Texture *texture = TextureManager::Instance().Add("wall.jpg");
    
    Camera camera;
    camera.setPosition(Vec3(0, 5, 15));
    camera.setTarget(Vec3(0, 0, 0));
    camera.setPerspective(60.0f, 1024.0f / 768.0f, 0.1f, 800.0f);

    Mesh *plane = MeshManager::Instance().CreatePlane("plane", 10, 10, 50, 50);
    Mesh *cube = MeshManager::Instance().CreateCube("cube");

    Shader *simpleDepthShader = ShaderManager::Instance().Create("depth", 
        depthVertexShader, depthFragmentShader);
    Shader *shader = ShaderManager::Instance().Create("shadow", 
        shadowVertexShader, shadowFragmentShader);
    Shader *debugShader = ShaderManager::Instance().Create("debug", 
        debugVertexShader, debugFragmentShader);

    // ===== CRIAR CSM (1 linha!) =====
    const int CASCADE_COUNT = 4;
    CascadedShadowMap *csm = new CascadedShadowMap(CASCADE_COUNT, 2048, 2048);

    Vec3 lightPos(-2, 4.0f, -4.0f);
    Vec3 cubePositions[] = {
        Vec3(0.0f, 0.0f, 0.0f),
        Vec3(2.0f, 5.0f, -15.0f),
        Vec3(-1.5f, 2.2f, -2.5f),
        Vec3(-3.8f, 2.0f, -12.3f),
        Vec3(2.4f, -0.4f, -3.5f),
        Vec3(-1.7f, 3.0f, -7.5f),
        Vec3(1.3f, 2.0f, -2.5f),
        Vec3(1.5f, 2.0f, -2.5f),
        Vec3(1.5f, 0.2f, -1.5f),
        Vec3(-1.3f, 1.0f, -1.5f)
    };

    QuadRenderer quad;
    float lastX = 0, lastY = 0;
    bool firstMouse = true;

    while (device.IsRunning())
    {
        float dt = device.GetFrameTime();
        const float SPEED = 12.0f * dt;

        lightPos.x = sin(device.GetTime()) * 3.0f;
        lightPos.z = cos(device.GetTime()) * 2.0f;
        lightPos.y = 5.0 + cos(device.GetTime()) * 1.0f;

        // Events...
        
        camera.update(1.0f);
        const Mat4 &view = camera.getViewMatrix();
        const Mat4 &proj = camera.getProjectionMatrix();
        const Vec3 cameraPos = camera.getPosition();

        driver.Clear(CLEAR_COLOR | CLEAR_DEPTH);

        float nearPlane = 0.1f;
        float farPlane = 800.0f;

        // ===== CALCULAR SPLITS E MATRIZES =====
        csm->CalculateSplits(nearPlane, farPlane);
        const auto& cascadeSplits = csm->GetSplits();
        
        std::vector<Mat4> lightSpaceMatrices;
        Vec3 lightDir = lightPos.normalized();
        
        float lastSplitDist = nearPlane;
        for (int i = 0; i < CASCADE_COUNT; ++i)
        {
            float splitDist = cascadeSplits[i];
            
            Mat4 proj = Mat4::Perspective(ToRadians(60.0f), 
                (float)1024 / (float)768, 
                lastSplitDist, splitDist);
            
            auto lightMatrix = getLightSpaceMatrix(lastSplitDist, splitDist, 
                proj, view, lightDir);
            lightSpaceMatrices.push_back(lightMatrix);
            
            lastSplitDist = splitDist;
        }

        // ===== RENDER SHADOW MAPS (código limpo!) =====
        simpleDepthShader->Bind();
        glViewport(0, 0, 2048, 2048);
        glEnable(GL_CULL_FACE);
        glCullFace(GL_FRONT);
        
        for (int cascade = 0; cascade < CASCADE_COUNT; ++cascade)
        {
            csm->BindCascade(cascade);
            csm->ClearCascade(cascade);
            
            simpleDepthShader->SetUniformMat4("lightSpaceMatrix", 
                lightSpaceMatrices[cascade].m);
            
            // Render scene
            for (int i = 0; i < 10; i++)
            {
                Mat4 model = Mat4::Translation(cubePositions[i]);
                simpleDepthShader->SetUniformMat4("model", model.m);
                cube->Render();
            }
        }
        
        glCullFace(GL_BACK);
        csm->Unbind();
        
        // ===== RENDER CENA PRINCIPAL =====
        glViewport(0, 0, 1024, 768);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        shader->Bind();
        shader->SetUniform("diffuseTexture", 0);
        shader->SetUniform("cascadeCount", CASCADE_COUNT);
        shader->SetUniform("showCascades", 0);
        shader->SetUniformMat4("projection", proj.m);
        shader->SetUniformMat4("view", view.m);
        shader->SetUniform("lightPos", lightPos.x, lightPos.y, lightPos.z);
        shader->SetUniform("viewPos", cameraPos.x, cameraPos.y, cameraPos.z);
        shader->SetUniform("farPlane", farPlane);
        shader->SetUniform("shadowMapSize", 2048, 2048);
        
        // Passar matrizes e splits
        for (int i = 0; i < CASCADE_COUNT; ++i)
        {
            std::string uniformName = "lightSpaceMatrices[" + std::to_string(i) + "]";
            shader->SetUniformMat4(uniformName.c_str(), lightSpaceMatrices[i].m);
            
            uniformName = "cascadePlaneDistances[" + std::to_string(i) + "]";
            shader->SetUniform(uniformName.c_str(), cascadeSplits[i]);
        }
        
        // ===== BIND SHADOW MAPS (super fácil!) =====
        texture->Bind(0);
        csm->BindAllTextures(1);  // Bind cascatas nos slots 1, 2, 3, 4

        // Render plano e cubos
        Mat4 model = Mat4::Scale(Vec3(2.0f));
        shader->SetUniformMat4("model", model.m);
        plane->Render();
        
        for (int i = 0; i < 10; i++)
        {
            model = Mat4::Translation(cubePositions[i]);
            shader->SetUniformMat4("model", model.m);
            cube->Render();
        }

        // ===== DEBUG: Visualizar cascatas =====
        debugShader->Bind();
        for (int i = 0; i < CASCADE_COUNT; ++i)
        {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, csm->GetDepthTexture(i));
            quad.render(i * 210, 0, 200, 200, 1024, 768);
        }

        device.Flip();
    }

    // ===== CLEANUP AUTOMÁTICO! =====
    delete csm;  // Limpa tudo automaticamente

    MeshManager::Instance().UnloadAll();
    ShaderManager::Instance().UnloadAll();
    TextureManager::Instance().UnloadAll();
    device.Close();

    return 0;
}

// ============================================================================
// RESUMO DAS MELHORIAS
// ============================================================================
/*
ANTES:
- ~50 linhas de código OpenGL manual
- Arrays separados (depthMapFBO, depthMaps, dummyColors)
- Configuração repetitiva em loop
- Cleanup manual de múltiplos recursos
- Propenso a erros (esquecer glBindTexture, etc)

AGORA:
- 1 linha para criar: new CascadedShadowMap(4, 2048, 2048)
- API simples: BindCascade(), ClearCascade(), BindAllTextures()
- Cleanup automático
- Menos erros
- Código muito mais legível
- Fácil de modificar número de cascatas

PERFORMANCE:
- Zero overhead - mesmo código GL por baixo
- Mesma performance que código manual
- Apenas abstração conveniente
*/
