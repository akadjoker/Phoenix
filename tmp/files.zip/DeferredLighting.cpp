// ============================================================================
// DEFERRED LIGHTING - Implementação
// ============================================================================

#include "DeferredLighting.hpp"

DeferredLighting::DeferredLighting(u32 w, u32 h) : width(w), height(h)
{
    // GBuffer: Position, Normal, Albedo+Specular
    gbuffer = new RenderTarget(width, height);
    gbuffer->AddColorAttachment(TextureFormat::RGB32F, "gPosition");
    gbuffer->AddColorAttachment(TextureFormat::RGB16F, "gNormal");
    gbuffer->AddColorAttachment(TextureFormat::RGBA8, "gAlbedoSpec");
    gbuffer->AddDepthAttachment(TextureFormat::DEPTH24);
    gbuffer->Build();
    
    // Light accumulation buffer (HDR)
    lightBuffer = new RenderTarget(width, height);
    lightBuffer->AddColorAttachment(TextureFormat::RGBA16F, "lighting");
    lightBuffer->Build();
    
    // Light volume meshes
    sphereMesh = MeshManager::Instance().CreateSphere("light_sphere", 1.0f, 16, 16);
    coneMesh = MeshManager::Instance().CreateCone("light_cone", 1.0f, 1.0f, 16);
    
    LogInfo("[DeferredLighting] Created (%ux%u)", width, height);
}

DeferredLighting::~DeferredLighting()
{
    delete gbuffer;
    delete lightBuffer;
}

void DeferredLighting::ClearLights()
{
    pointLights.clear();
    spotLights.clear();
}

void DeferredLighting::AddPointLight(const PointLight& light)
{
    pointLights.push_back(light);
}

void DeferredLighting::AddSpotLight(const SpotLight& light)
{
    spotLights.push_back(light);
}

PointLight* DeferredLighting::GetPointLight(u32 index)
{
    return index < pointLights.size() ? &pointLights[index] : nullptr;
}

SpotLight* DeferredLighting::GetSpotLight(u32 index)
{
    return index < spotLights.size() ? &spotLights[index] : nullptr;
}

void DeferredLighting::BeginGBufferPass()
{
    gbuffer->Bind();
    gbuffer->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void DeferredLighting::EndGBufferPass()
{
    gbuffer->Unbind();
}

void DeferredLighting::BeginLightingPass()
{
    lightBuffer->Bind();
    lightBuffer->Clear(GL_COLOR_BUFFER_BIT);
    
    // Copiar depth do GBuffer
    glBindFramebuffer(GL_READ_FRAMEBUFFER, gbuffer->GetHandle());
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, lightBuffer->GetHandle());
    glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, 
                     GL_DEPTH_BUFFER_BIT, GL_NEAREST);
    glBindFramebuffer(GL_FRAMEBUFFER, lightBuffer->GetHandle());
}

void DeferredLighting::EndLightingPass()
{
    lightBuffer->Unbind();
}

void DeferredLighting::BindGBufferTextures(u32 startSlot)
{
    gbuffer->GetTexture("gPosition")->Bind(startSlot + 0);
    gbuffer->GetTexture("gNormal")->Bind(startSlot + 1);
    gbuffer->GetTexture("gAlbedoSpec")->Bind(startSlot + 2);
}

void DeferredLighting::Resize(u32 w, u32 h)
{
    width = w;
    height = h;
    gbuffer->Resize(w, h);
    lightBuffer->Resize(w, h);
}
