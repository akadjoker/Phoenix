// ============================================================================
// CascadedShadowMap - Classe para Cascaded Shadow Maps
// ============================================================================

#pragma once

#include "RenderTarget.hpp"
#include <vector>

class CascadedShadowMap
{
private:
    u32 cascadeCount;
    u32 shadowWidth;
    u32 shadowHeight;
    std::vector<RenderTarget*> cascades;
    std::vector<float> splits;
    
public:
    CascadedShadowMap(u32 count, u32 width, u32 height)
        : cascadeCount(count), shadowWidth(width), shadowHeight(height)
    {
        // Criar render target para cada cascata
        for (u32 i = 0; i < cascadeCount; i++)
        {
            RenderTarget *rt = new RenderTarget(shadowWidth, shadowHeight);
            rt->AddDepthAttachment(TextureFormat::DEPTH24, true);
            
            // Opcional: adicionar color attachment dummy se necessário
            // (alguns drivers precisam)
            rt->AddColorAttachment(TextureFormat::RGBA8, "dummy", false);
            
            if (!rt->Build())
            {
                LogError("[CSM] Failed to create cascade %d", i);
                delete rt;
                continue;
            }
            
            // Configurar textura de profundidade para shadow mapping
            Texture *depthTex = rt->GetDepthTexture();
            if (depthTex)
            {
                depthTex->SetMinFilter(FilterMode::LINEAR);
                depthTex->SetMagFilter(FilterMode::LINEAR);
                depthTex->SetWrap(WrapMode::CLAMP_TO_BORDER);
                depthTex->SetBorderColor(1.0f, 1.0f, 1.0f, 1.0f);
            }
            
            cascades.push_back(rt);
        }
        
        LogInfo("[CSM] Created %d cascades (%ux%u)", cascadeCount, shadowWidth, shadowHeight);
    }
    
    ~CascadedShadowMap()
    {
        for (auto *rt : cascades)
            delete rt;
    }
    
    // Bind cascade específica para renderizar
    void BindCascade(u32 index)
    {
        if (index < cascades.size())
            cascades[index]->Bind();
    }
    
    void Unbind()
    {
        RenderTarget::BindDefault();
    }
    
    // Clear cascade específica
    void ClearCascade(u32 index)
    {
        if (index < cascades.size())
            cascades[index]->Clear(GL_DEPTH_BUFFER_BIT);
    }
    
    // Obter texture ID para usar no shader
    u32 GetDepthTexture(u32 index) const
    {
        if (index < cascades.size())
        {
            Texture *tex = cascades[index]->GetDepthTexture();
            return tex ? tex->GetHandle() : 0;
        }
        return 0;
    }
    
    // Bind todas as texturas de uma vez (útil para o shader)
    void BindAllTextures(u32 startSlot)
    {
        for (u32 i = 0; i < cascades.size(); i++)
        {
            Texture *tex = cascades[i]->GetDepthTexture();
            if (tex)
                tex->Bind(startSlot + i);
        }
    }
    
    // Getters
    u32 GetCascadeCount() const { return cascadeCount; }
    u32 GetWidth() const { return shadowWidth; }
    u32 GetHeight() const { return shadowHeight; }
    
    // Calcular splits (mesma função do teu código)
    void CalculateSplits(float nearPlane, float farPlane, float lambda = 0.75f)
    {
        splits.resize(cascadeCount);
        
        for (u32 i = 0; i < cascadeCount; ++i)
        {
            float p = (i + 1) / static_cast<float>(cascadeCount);
            float log = nearPlane * std::pow(farPlane / nearPlane, p);
            float uniform = nearPlane + (farPlane - nearPlane) * p;
            splits[i] = lambda * log + (1.0f - lambda) * uniform;
        }
    }
    
    const std::vector<float>& GetSplits() const { return splits; }
    float GetSplit(u32 index) const { return index < splits.size() ? splits[index] : 0.0f; }
    
    // Delete copy
    CascadedShadowMap(const CascadedShadowMap&) = delete;
    CascadedShadowMap& operator=(const CascadedShadowMap&) = delete;
};
