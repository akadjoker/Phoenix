// ============================================================================
// DEFERRED RENDERING + CASCADED SHADOW MAPS
// A combinação perfeita para jogos modernos!
// ============================================================================

/*
ARQUITETURA:

PASS 1: Shadow Maps (Cascaded)
  └─> Render depth para 4 cascatas
  
PASS 2: GBuffer (Geometry)
  └─> Render geometria (Position, Normal, Albedo)
  
PASS 3: Lighting (Deferred)
  └─> Combina GBuffer + Shadow Maps
  └─> Calcula lighting uma vez só por pixel!

VANTAGENS:
✅ Performance excelente com múltiplas luzes
✅ Sombras de alta qualidade a qualquer distância
✅ Separa geometria de lighting
✅ Fácil adicionar mais técnicas (SSAO, etc)
*/

#pragma once
#include "RenderTarget.hpp"
#include "CascadedShadowMap.hpp"

// ============================================================================
// CLASSE SIMPLES: Deferred + CSM
// ============================================================================

class DeferredCSM
{
private:
    // GBuffer
    RenderTarget *gbuffer;
    
    // Shadow maps
    CascadedShadowMap *csm;
    
    u32 width, height;
    
public:
    DeferredCSM(u32 w, u32 h) : width(w), height(h)
    {
        // GBuffer simples: Position, Normal, Albedo, Depth
        gbuffer = new RenderTarget(width, height);
        gbuffer->AddColorAttachment(TextureFormat::RGB32F, "gPosition");
        gbuffer->AddColorAttachment(TextureFormat::RGB16F, "gNormal");
        gbuffer->AddColorAttachment(TextureFormat::RGBA8, "gAlbedo");
        gbuffer->AddDepthAttachment(TextureFormat::DEPTH24);
        gbuffer->Build();
        
        // Cascaded shadow maps (4 cascatas, 2048x2048)
        csm = new CascadedShadowMap(4, 2048, 2048);
        
        LogInfo("[DeferredCSM] Created (%ux%u)", width, height);
    }
    
    ~DeferredCSM()
    {
        delete gbuffer;
        delete csm;
    }
    
    RenderTarget* GetGBuffer() { return gbuffer; }
    CascadedShadowMap* GetCSM() { return csm; }
    
    void Resize(u32 w, u32 h)
    {
        width = w;
        height = h;
        gbuffer->Resize(w, h);
    }
};
